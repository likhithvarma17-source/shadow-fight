// Game template dev server: serves the exported web build and re-exports on
// every start. The listener comes up first so the runtime discovers the port
// immediately; the export runs in the background.
import { spawn } from 'node:child_process'
import { createReadStream, existsSync, mkdirSync, readFileSync, statSync } from 'node:fs'
import { createServer } from 'node:http'
import { extname, join } from 'node:path'
import {
  COLLECTOR_URL,
  LOGS_URL,
  handleLogPost,
  injectCollectorTag,
  serveCollector,
} from './scripts/debug-logs.mjs'
import {
  missingAssets,
  readAssetsManifest,
  releaseExportLock,
  sourceFingerprint,
  tryAcquireExportLock,
  writeBuildFingerprint,
} from './scripts/artifacts-lib.mjs'
import { decodeUrlPath, resolveDistFile } from './scripts/server-paths.mjs'

const PORT = Number(process.env.PORT || 3000)
const DIST = join(process.cwd(), 'dist')
const EXPORT_CMD = ['--headless', '--path', '.', '--export-release', 'Web', 'dist/index.html']

// Published sites serve /manus-storage/<key> natively; mirroring it here keeps
// the published shell behaving identically in the dev preview.
function loadStorageApiConfig() {
  let url = process.env.BUILT_IN_FORGE_API_URL || ''
  let key = process.env.BUILT_IN_FORGE_API_KEY || ''
  if (!url || !key) {
    try {
      const env = readFileSync('/opt/.manus/webdev.env', 'utf8')
      for (const line of env.split('\n')) {
        const m = line.match(/^(?:export\s+)?(BUILT_IN_FORGE_API_URL|BUILT_IN_FORGE_API_KEY)=("?)(.*)\2$/)
        if (m) {
          if (m[1] === 'BUILT_IN_FORGE_API_URL' && !url) url = m[3]
          if (m[1] === 'BUILT_IN_FORGE_API_KEY' && !key) key = m[3]
        }
      }
    } catch {
      /* env file absent — proxy disabled */
    }
  }
  return { url: url.replace(/\/+$/, ''), key }
}

async function handleStorageProxy(req, res, urlPath) {
  const storageKey = urlPath.replace(/^\/manus-storage\//, '')
  const { url, key } = loadStorageApiConfig()
  if (!storageKey || !storagePathBelongsToProject(urlPath)) {
    res.writeHead(403, { 'Cache-Control': 'no-store' }).end('Forbidden')
    return
  }
  if (!url || !key) {
    res.writeHead(502, { 'Cache-Control': 'no-store' }).end('Storage proxy not configured')
    return
  }
  try {
    const presign = new URL('v1/storage/presign/get', url + '/')
    presign.searchParams.set('path', storageKey)
    const r = await fetch(presign, { headers: { Authorization: `Bearer ${key}` } })
    if (!r.ok) {
      res.writeHead(502, { 'Cache-Control': 'no-store' }).end(`Storage backend error (${r.status})`)
      return
    }
    const { url: signed } = await r.json()
    if (!signed) {
      res.writeHead(502, { 'Cache-Control': 'no-store' }).end('Empty signed URL from backend')
      return
    }
    res.writeHead(307, { Location: signed, 'Cache-Control': 'no-store' }).end()
  } catch (err) {
    res.writeHead(502, { 'Cache-Control': 'no-store' }).end(`Storage proxy error: ${err?.message || err}`)
  }
}

function storagePathBelongsToProject(urlPath) {
  const paths = new Set()
  try {
    for (const entry of Object.values(readAssetsManifest(process.cwd()).assets)) {
      if (entry.path.startsWith('/manus-storage/')) paths.add(entry.path)
    }
  } catch {
    return false
  }
  try {
    const state = JSON.parse(readFileSync(join(process.cwd(), '.manus-artifacts.json'), 'utf8'))
    for (const key of ['pck_url', 'wasm_url']) {
      if (typeof state[key] === 'string' && state[key].startsWith('/manus-storage/')) paths.add(state[key])
    }
  } catch {}
  return paths.has(urlPath)
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.wasm': 'application/wasm',
  '.pck': 'application/octet-stream',
  '.png': 'image/png',
  '.webp': 'image/webp',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.wav': 'audio/wav',
  '.ogg': 'audio/ogg',
  '.mp3': 'audio/mpeg',
  '.txt': 'text/plain; charset=utf-8',
}

let exportState = 'exporting' // exporting | ready | failed
const exportLog = []
function logExport(line) {
  process.stdout.write(line.endsWith('\n') ? line : line + '\n')
  for (const l of line.split('\n')) {
    if (l.trim()) exportLog.push(l)
  }
  while (exportLog.length > 60) exportLog.shift()
}

function runExport() {
  exportState = 'exporting'
  exportLog.length = 0
  mkdirSync(DIST, { recursive: true })
  startExportWhenLockFree()
}

// The checkpoint hook takes the same lock; concurrent godot runs would
// produce torn builds.
function startExportWhenLockFree() {
  if (!tryAcquireExportLock(process.cwd())) {
    logExport('[export] another export is in flight — waiting for it to finish')
    setTimeout(startExportWhenLockFree, 2000)
    return
  }
  // Assets live in project storage, not git. Restoring runs in its own process
  // because the downloads block and would stall the listener that just came up.
  if (missingAssets(process.cwd()).length) {
    logExport('[assets] restoring assets recorded in assets.lock.json...')
    const hydrator = spawn('node', ['scripts/hydrate-assets.mjs'], { cwd: process.cwd() })
    hydrator.stdout.on('data', (d) => logExport(d.toString()))
    hydrator.stderr.on('data', (d) => logExport(d.toString()))
    hydrator.on('error', (err) => {
      finishExportWithAssetFailure(`could not start asset restore: ${err.message}`)
    })
    hydrator.on('exit', () => startExportAfterHydration())
    return
  }
  startExportAfterHydration()
}

function finishExportWithAssetFailure(detail) {
  exportState = 'failed'
  releaseExportLock(process.cwd())
  logExport(`[export] refusing to export: ${detail}`)
  logExport('[export] fix storage access (or remove stale entries from assets.lock.json), then restart the dev server')
}

// Runs with the export lock already held.
function startExportAfterHydration() {
  const missing = missingAssets(process.cwd())
  if (missing.length) {
    finishExportWithAssetFailure(
      `${missing.length} recorded asset(s) missing locally: ${missing.slice(0, 5).join(', ')}`,
    )
    return
  }
  // Capture BEFORE the export: sources edited while godot runs must invalidate
  // this build for the checkpoint hook.
  let fingerprint
  try {
    fingerprint = sourceFingerprint(process.cwd())
  } catch (err) {
    logExport(`[export] warning: could not fingerprint sources: ${err?.message || err}`)
  }
  logExport(`[export] godot ${EXPORT_CMD.join(' ')}`)
  const child = spawn('godot', EXPORT_CMD, { cwd: process.cwd() })
  child.stdout.on('data', (d) => logExport(d.toString()))
  child.stderr.on('data', (d) => logExport(d.toString()))
  child.on('error', (err) => {
    exportState = 'failed'
    releaseExportLock(process.cwd())
    logExport(`[export] failed to launch godot: ${err.message}`)
  })
  child.on('exit', (code) => {
    if (code === 0 && existsSync(join(DIST, 'index.html'))) {
      exportState = 'ready'
      // Written while the lock is held so a waiting hook sees dist/ and the
      // fingerprint as one consistent unit.
      try {
        if (fingerprint) writeBuildFingerprint(process.cwd(), fingerprint)
      } catch (err) {
        logExport(`[export] warning: could not write build fingerprint: ${err?.message || err}`)
      }
      logExport('[export] done — game build is ready')
    } else {
      exportState = 'failed'
      logExport(`[export] godot exited with code ${code}`)
    }
    releaseExportLock(process.cwd())
  })
}

function placeholderPage() {
  const title = exportState === 'failed' ? 'Game export failed' : 'Exporting game…'
  const refresh = exportState === 'failed' ? '' : '<meta http-equiv="refresh" content="2">'
  const tail = exportLog.slice(-25).join('\n').replace(/&/g, '&amp;').replace(/</g, '&lt;')
  return `<!doctype html><html><head><meta charset="utf-8">${refresh}<title>${title}</title>
<style>body{font-family:ui-monospace,monospace;background:#111;color:#ddd;padding:2rem;max-width:60rem;margin:auto}
h1{font-size:1.1rem}pre{white-space:pre-wrap;background:#000;padding:1rem;border-radius:8px;font-size:.8rem}</style>
</head><body><h1>${title}</h1><p>${
    exportState === 'failed'
      ? 'The Godot web export failed. Fix the errors below and restart the dev server to re-export.'
      : 'The Godot web export is running. This page refreshes automatically.'
  }</p><pre>${tail || '(no output yet)'}</pre></body></html>`
}

const server = createServer((req, res) => {
  const urlPath = decodeUrlPath(req.url)
  if (urlPath === null) {
    res.writeHead(400, { 'Cache-Control': 'no-store' }).end('Bad request')
    return
  }
  if (urlPath.startsWith('/manus-storage/')) {
    void handleStorageProxy(req, res, urlPath)
    return
  }
  if (urlPath === COLLECTOR_URL) {
    serveCollector(res)
    return
  }
  if (urlPath === LOGS_URL && req.method === 'POST') {
    handleLogPost(req, res)
    return
  }
  let filePath = resolveDistFile(DIST, urlPath)
  if (!filePath) {
    res.writeHead(403).end('Forbidden')
    return
  }
  let stat
  try {
    stat = statSync(filePath)
    if (stat.isDirectory()) {
      filePath = join(filePath, 'index.html')
      stat = statSync(filePath)
    }
  } catch {
    stat = undefined
  }
  if (!stat) {
    if (urlPath === '/' || urlPath === '/index.html' || !existsSync(join(DIST, 'index.html'))) {
      res.writeHead(exportState === 'failed' ? 500 : 503, {
        'Content-Type': 'text/html; charset=utf-8',
        'Cache-Control': 'no-store',
      })
      res.end(placeholderPage())
    } else {
      res.writeHead(404, { 'Cache-Control': 'no-store' }).end('Not found')
    }
    return
  }
  const ext = extname(filePath).toLowerCase()
  // Rewritten in the response only, so dist/index.html and the publish shell
  // assembled from it stay clean. Everything else streams.
  if (ext === '.html') {
    const body = injectCollectorTag(readFileSync(filePath, 'utf8'))
    res.writeHead(200, {
      'Content-Type': MIME[ext],
      'Content-Length': Buffer.byteLength(body),
      'Cache-Control': 'no-store',
    })
    res.end(body)
    return
  }
  res.writeHead(200, {
    'Content-Type': MIME[ext] || 'application/octet-stream',
    'Content-Length': stat.size,
    'Cache-Control': 'no-store',
  })
  createReadStream(filePath).pipe(res)
})

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Serving on http://localhost:${PORT}`)
  runExport()
})
