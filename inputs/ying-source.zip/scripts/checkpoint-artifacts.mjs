#!/usr/bin/env node
// Checkpoint artifacts hook — executed automatically by the sandbox webdev
// service before every checkpoint commit (generic contract: any project with
// scripts/checkpoint-artifacts.mjs gets it run; its final JSON line is
// attached to the checkpoint).
//
// Ensures the checkpoint is publishable: build matches sources, artifacts are
// uploaded (content-deduplicated), ./site references this version's URLs.
// The machine-readable result MUST be the last stdout line, prefixed with
// __CHECKPOINT_ARTIFACTS__.
import { prepareArtifacts } from './artifacts-lib.mjs'

const artifacts = prepareArtifacts(process.cwd())
console.log('__CHECKPOINT_ARTIFACTS__ ' + JSON.stringify(artifacts))
