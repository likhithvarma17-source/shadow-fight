import { execFileSync } from 'node:child_process'
import { existsSync, mkdtempSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const packPath = resolve(projectRoot, process.argv[2] || 'dist/index.pck')
const godot = process.env.GODOT_BIN || 'godot'
const maxPackBytes = 5 * 1024 * 1024

if (!existsSync(packPath)) {
	throw new Error(`exported pack not found: ${packPath}`)
}
const packBytes = statSync(packPath).size
if (packBytes > maxPackBytes) {
	throw new Error(`exported pack exceeds 5 MiB: ${packBytes} > ${maxPackBytes} bytes`)
}
console.log(`[PCK_SIZE_PASS] ${packBytes} <= ${maxPackBytes} bytes`)

const preset = readFileSync(resolve(projectRoot, 'export_presets.cfg'), 'utf8')
const filterMatch = preset.match(/^exclude_filter="([^"]*)"$/m)
if (!filterMatch) throw new Error('Web export exclude_filter not found')
const excludePatterns = filterMatch[1]
  .split(',')
  .map((pattern) => pattern.trim())
  .filter(Boolean)
const directoryPattern = /^([^*?]+)\/\*$/
const excludedDirectories = excludePatterns.map((pattern) => pattern.match(directoryPattern)?.[1]).filter(Boolean)
const exactFilePattern = /^[^*?]+$/
const excludedFiles = excludePatterns.filter((pattern) => !directoryPattern.test(pattern) && exactFilePattern.test(pattern))
const unsupportedPatterns = excludePatterns.filter((pattern) => !directoryPattern.test(pattern) && !exactFilePattern.test(pattern))
if (excludedDirectories.length === 0) throw new Error('Web export has no directory exclusions')
if (unsupportedPatterns.length > 0) {
  console.warn(`[PCK_CONTENTS_WARN] patterns not verified: ${unsupportedPatterns.join(', ')}`)
}

const runDirectory = mkdtempSync(join(tmpdir(), 'game-pck-check-'))
const contentsProbe = resolve(runDirectory, 'exported_pack_contents.gd')
const requiredDirectoryLines = ['scenes', 'scripts']
  .map((directory) => `\t${JSON.stringify(`res://${directory}`)},`)
  .join('\n')
const requiredResourceLines = [
	  'assets/fonts/fusion-pixel-12px-proportional-zh_hans.woff2',
		  'assets/audio/zero_hour_bgm_reverse.ogg',
		  'assets/audio/warden_boss_theme.ogg',
		  'assets/audio/rewind_signal_noise.ogg',
		  'assets/audio/dialogue_type_tick.ogg',
		  'assets/environment/interior_hideout.webp',
		  'scenes/interior_level.tscn',
		  'assets/story/briefing_flip_phone.webp',
	'assets/story/post_boss/panel_01_warehouse.webp',
	'assets/story/post_boss/panel_02_crate.webp',
	'assets/story/post_boss/panel_03_blade.webp',
	'assets/story/post_boss/panel_04_cat.webp',
]
  .map((resource) => `\t${JSON.stringify(`res://${resource}`)},`)
  .join('\n')
const requiredFileLines = [
  'data/story.xml',
  'data/licenses/fusion-pixel-font-OFL.txt',
  'data/licenses/ark-pixel-font-OFL.txt',
  'data/licenses/cubic-11-OFL.txt',
  'data/licenses/galmuri-license.txt',
]
  .map((file) => `\t${JSON.stringify(`res://${file}`)},`)
  .join('\n')
const directoryLines = excludedDirectories.map((directory) => `\t${JSON.stringify(`res://${directory}`)},`).join('\n')
const excludedFileLines = excludedFiles.map((file) => `\t${JSON.stringify(`res://${file}`)},`).join('\n')
writeFileSync(
  contentsProbe,
		  `extends SceneTree\n\nconst REQUIRED_DIRECTORIES := [\n${requiredDirectoryLines}\n]\nconst REQUIRED_RESOURCES := [\n${requiredResourceLines}\n]\nconst REQUIRED_FILES := [\n${requiredFileLines}\n]\nconst EXCLUDED_DIRECTORIES := [\n${directoryLines}\n]\nconst EXCLUDED_FILES := [\n${excludedFileLines}\n]\n\nfunc _initialize() -> void:\n\tfor directory in REQUIRED_DIRECTORIES:\n\t\tif not DirAccess.dir_exists_absolute(directory):\n\t\t\tpush_error("[PCK_CONTENTS_FAIL] pack not mounted or required directory missing: " + directory)\n\t\t\tquit(1)\n\t\t\treturn\n\tfor resource in REQUIRED_RESOURCES:\n\t\tif not ResourceLoader.exists(resource):\n\t\t\tpush_error("[PCK_CONTENTS_FAIL] required resource missing: " + resource)\n\t\t\tquit(1)\n\t\t\treturn\n\tfor file in REQUIRED_FILES:\n\t\tif not FileAccess.file_exists(file):\n\t\t\tpush_error("[PCK_CONTENTS_FAIL] required file missing: " + file)\n\t\t\tquit(1)\n\t\t\treturn\n\tfor directory in EXCLUDED_DIRECTORIES:\n\t\tif DirAccess.dir_exists_absolute(directory):\n\t\t\tpush_error("[PCK_CONTENTS_FAIL] excluded directory present: " + directory)\n\t\t\tquit(1)\n\t\t\treturn\n\tfor file in EXCLUDED_FILES:\n\t\tif FileAccess.file_exists(file):\n\t\t\tpush_error("[PCK_CONTENTS_FAIL] excluded file present: " + file)\n\t\t\tquit(1)\n\t\t\treturn\n\tprint("[PCK_CONTENTS_PASS] XML story, Fusion Pixel font, exploration/reverse/Warden BGM, signal noise, generated story art, and licenses present; exclusions absent")\n\tquit(0)\n`,
)

const checks = [contentsProbe, resolve(projectRoot, 'test/exported_pack_boot.gd')]
let failed = false
try {
  for (const script of checks) {
    try {
      execFileSync(godot, ['--headless', '--main-pack', packPath, '--script', script], {
        cwd: runDirectory,
        stdio: 'inherit',
      })
    } catch (error) {
      if (error?.code === 'ENOENT') {
        console.error(`[PCK_CHECK_FAIL] Godot binary not found: ${godot}; set GODOT_BIN to override`)
      } else {
        console.error(`[PCK_CHECK_FAIL] ${script}: ${error instanceof Error ? error.message : String(error)}`)
      }
      failed = true
      break
    }
  }
} finally {
  rmSync(runDirectory, { recursive: true, force: true })
}

if (failed) process.exitCode = 1
