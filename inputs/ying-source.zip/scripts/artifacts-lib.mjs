// Implementation behind scripts/checkpoint-artifacts.mjs, the hook that runs
// on every webdev_save_checkpoint. Saving a checkpoint is the only thing that
// produces publish artifacts, so ./site cannot drift from committed sources.
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import {
  closeSync,
  cpSync,
  existsSync,
  lstatSync,
  mkdirSync,
  openSync,
  readFileSync,
  readSync,
  readdirSync,
  renameSync,
  rmSync,
  statSync,
  writeFileSync,
} from 'node:fs'
import { dirname, join, relative, resolve, sep } from 'node:path'

const LARGE = ['index.wasm', 'index.pck']
const STATE_FILE = '.manus-artifacts.json'
const BUILD_FINGERPRINT_FILE = join('dist', '.build-fingerprint')
const EXPORT_LOCK_FILE = join('dist', '.export-lock')
const EXPORT_LOCK_STALE_MS = 20 * 60_000
const EXPORT_LOCK_WAIT_MS = 16 * 60_000
const SKIP_DIRS = new Set([
  '.git',
  'node_modules',
  'dist',
  'site',
  '.godot',
  '.manus-logs',
  'test-output',
  'game-captures',
])
// Transient files must not churn the fingerprint into constant re-exports.
const SKIP_FILES = new Set([STATE_FILE, '.DS_Store'])
const SKIP_SUFFIXES = ['.log', '.tmp']

export function sourceFingerprint(root = process.cwd()) {
  const files = []
  const walk = (dir) => {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      if (entry.isDirectory()) {
        if (!SKIP_DIRS.has(entry.name)) walk(join(dir, entry.name))
      } else if (
        entry.isFile() &&
        !SKIP_FILES.has(entry.name) &&
        !SKIP_SUFFIXES.some((s) => entry.name.endsWith(s))
      ) {
        files.push(join(dir, entry.name))
      }
    }
  }
  walk(root)
  files.sort()
  const hash = createHash('sha256')
  for (const f of files) {
    hash.update(relative(root, f).split(sep).join('/'))
    hash.update('\0')
    hash.update(readFileSync(f))
    hash.update('\0')
  }
  return 'sha256:' + hash.digest('hex')
}

// Capture BEFORE the export starts: sources edited while godot runs must
// invalidate the build, not be stamped as already built.
export function writeBuildFingerprint(root = process.cwd(), fingerprint = sourceFingerprint(root)) {
  writeFileSync(join(root, BUILD_FINGERPRINT_FILE), fingerprint)
}

function exportLockHolder(root) {
  try {
    const lockPath = join(root, EXPORT_LOCK_FILE)
    const pid = Number(readFileSync(lockPath, 'utf8').trim())
    if (!pid || Date.now() - statSync(lockPath).mtimeMs > EXPORT_LOCK_STALE_MS) return 0
    process.kill(pid, 0)
    return pid
  } catch {
    return 0
  }
}

// Only one exporter (dev-server boot or checkpoint hook) may write dist/ at a
// time, or the hook could hash and upload a half-written artifact.
export function tryAcquireExportLock(root = process.cwd()) {
  mkdirSync(join(root, 'dist'), { recursive: true })
  if (exportLockHolder(root)) return false
  rmSync(join(root, EXPORT_LOCK_FILE), { force: true })
  try {
    writeFileSync(join(root, EXPORT_LOCK_FILE), String(process.pid), { flag: 'wx' })
    return true
  } catch {
    return false
  }
}

export function releaseExportLock(root = process.cwd()) {
  try {
    const pid = Number(readFileSync(join(root, EXPORT_LOCK_FILE), 'utf8').trim())
    if (pid === process.pid) rmSync(join(root, EXPORT_LOCK_FILE), { force: true })
  } catch {
    /* already gone */
  }
}

function acquireExportLockSync(root) {
  const deadline = Date.now() + EXPORT_LOCK_WAIT_MS
  for (;;) {
    if (tryAcquireExportLock(root)) return
    const holder = exportLockHolder(root)
    if (Date.now() > deadline) {
      throw new Error(`another export (pid ${holder || 'unknown'}) is still running; retry the checkpoint later`)
    }
    if (holder) console.log(`[artifacts] waiting for in-flight export (pid ${holder}) to finish...`)
    Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 2000)
  }
}

function fileSha256(path) {
  const hash = createHash('sha256')
  const buffer = Buffer.allocUnsafe(1024 * 1024)
  const file = openSync(path, 'r')
  try {
    for (;;) {
      const bytes = readSync(file, buffer, 0, buffer.length, null)
      if (!bytes) break
      hash.update(buffer.subarray(0, bytes))
    }
  } finally {
    closeSync(file)
  }
  return 'sha256:' + hash.digest('hex')
}

function godotEngineVersion() {
  const out = execFileSync('godot', ['--version'], { encoding: 'utf8', timeout: 60_000 })
  const m = out.match(/(\d+\.\d+(?:\.\d+)?)/)
  return m ? m[1] : out.trim().slice(0, 20)
}

function exportBuild(root, fingerprint) {
  assertAssetsPresent(root)
  console.log('[artifacts] exporting web build...')
  mkdirSync(join(root, 'dist'), { recursive: true })
  execFileSync('godot', ['--headless', '--path', '.', '--export-release', 'Web', 'dist/index.html'], {
    cwd: root,
    stdio: 'inherit',
    timeout: 15 * 60_000,
  })
  for (const f of LARGE) {
    if (!existsSync(join(root, 'dist', f))) throw new Error(`export incomplete: dist/${f} missing`)
  }
  writeBuildFingerprint(root, fingerprint)
}

function uploadToStorage(root, filePath) {
  const out = execFileSync('manus-upload-file', ['--webdev', filePath], {
    cwd: root,
    encoding: 'utf8',
    timeout: 10 * 60_000,
  })
  process.stdout.write(out)
  const m = out.match(/Storage Path:\s*(\/manus-storage\/\S+)/)
  if (!m) throw new Error(`could not parse storage path for ${filePath}`)
  return m[1]
}

function assembleSite(root, remap) {
  const dist = join(root, 'dist')
  const site = join(root, 'site')
  rmSync(site, { recursive: true, force: true })
  mkdirSync(site, { recursive: true })
  for (const entry of readdirSync(dist)) {
    if (LARGE.includes(entry) || entry === '.build-fingerprint' || entry === '.export-lock') continue
    cpSync(join(dist, entry), join(site, entry), { recursive: true })
  }
  const remapScript = `<script>(function(){var R=${JSON.stringify(remap)};var f=window.fetch.bind(window);window.fetch=function(i,o){var u=typeof i==="string"?i:(i&&i.url)||"";var b=u.split("?")[0].split("/").pop();return R[b]?f(R[b],o):f(i,o)};})();</script>`
  const shellPath = join(site, 'index.html')
  const shell = readFileSync(shellPath, 'utf8')
  if (!shell.includes('<script')) throw new Error('exported index.html has no <script> tag to anchor the remap patch')
  const patched = shell.replace('<script', `${remapScript}\n<script`)
  // The collector is injected into responses only; reaching the shell would
  // ship players a dev tool posting to an endpoint they cannot reach.
  if (patched.includes('__manus__')) {
    throw new Error('publish shell references a dev-only endpoint; collector injection must stay response-only')
  }
  writeFileSync(shellPath, patched)
  let total = 0
  for (const entry of readdirSync(site)) total += statSync(join(site, entry)).size
  return total
}

function readState(root) {
  try {
    return JSON.parse(readFileSync(join(root, STATE_FILE), 'utf8'))
  } catch {
    return {}
  }
}

function writeState(root, patch) {
  const next = { ...readState(root), ...patch }
  writeFileSync(join(root, STATE_FILE), JSON.stringify(next, null, 2))
  return next
}

// Asset sync: binary assets never enter git. assets.lock.json (committed) maps
// each project-relative path to its storage location and content hash, and the
// tree is made whole from it before every export.

const ASSETS_LOCK_FILE = 'assets.lock.json'
const ASSETS_DIR = 'assets'
const MAX_ASSET_SIZE_BYTES = 512 * 1024 * 1024
const PUBLIC_ASSET_HOSTS = new Set([
  'files.manuscdn.com',
  'd1oupeiobkpcny.cloudfront.net',
])
const ASSET_TYPE_BY_EXT = new Map([
  ['.png', 'image'],
  ['.jpg', 'image'],
  ['.jpeg', 'image'],
  ['.webp', 'image'],
  ['.gif', 'image'],
  ['.bmp', 'image'],
  ['.svg', 'image'],
  ['.ico', 'image'],
  ['.ogg', 'audio'],
  ['.wav', 'audio'],
  ['.mp3', 'audio'],
  ['.m4a', 'audio'],
  ['.mp4', 'video'],
  ['.webm', 'video'],
  ['.ttf', 'font'],
  ['.otf', 'font'],
  ['.woff', 'font'],
  ['.woff2', 'font'],
])
const ASSET_EXTS = new Set(ASSET_TYPE_BY_EXT.keys())

function emptyAssetsManifest() {
  return { version: 2, groups: {}, assets: {} }
}

function normalizeGroupId(value) {
  if (typeof value !== 'string') return ''
  return value
    .trim()
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, '-')
    .replace(/^-+|-+$/g, '')
}

export function defaultGroupId(rel) {
  const parts = rel.split('/').slice(1, -1)
  if (parts[0] === 'template') return 'template'
  return normalizeGroupId(parts[0]) || 'ungrouped'
}

function projectGroupId(rel) {
  const parts = rel.split('/').slice(1, -1)
  if (parts[0] === 'template') parts.shift()
  return normalizeGroupId(parts[0]) || 'ungrouped'
}

function defaultGroupName(groupId) {
  return groupId
    .split('-')
    .filter(Boolean)
    .map((part) => part[0].toUpperCase() + part.slice(1))
    .join(' ')
}

export function assetTypeOf(rel) {
  return ASSET_TYPE_BY_EXT.get(extOf(rel)) || ''
}

function isManagedAssetRel(rel) {
  return (
    typeof rel === 'string' &&
    !rel.startsWith('/') &&
    !rel.includes('\\') &&
    !rel.split('/').some((part) => !part || part === '.' || part === '..') &&
    ASSET_EXTS.has(extOf(rel))
  )
}

function isAssetRel(rel) {
  return isManagedAssetRel(rel) && rel.startsWith(`${ASSETS_DIR}/`)
}

function normalizeAssetEntry(rel, value, requireType = false) {
  if (!isManagedAssetRel(rel)) return null
  if (!value || typeof value !== 'object') return null
  const assetType = assetTypeOf(rel)
  if (requireType && value.assetType !== assetType) return null
  if (typeof value.path !== 'string' || !assetLocation(value.path)) return null
  if (requireType && (typeof value.sha256 !== 'string' || !/^sha256:[a-f0-9]{64}$/.test(value.sha256))) return null
  if (typeof value.sha256 === 'string' && value.sha256 && !/^sha256:[a-f0-9]{64}$/.test(value.sha256)) return null
  if (requireType && (!Number.isSafeInteger(value.size) || value.size <= 0 || value.size > MAX_ASSET_SIZE_BYTES)) return null
  if (typeof value.size === 'number' && (value.size < 0 || value.size > MAX_ASSET_SIZE_BYTES)) return null
  const groupId = normalizeGroupId(value.groupId) || defaultGroupId(rel)
  const entry = {
    path: value.path,
    sha256: typeof value.sha256 === 'string' ? value.sha256 : '',
    size: typeof value.size === 'number' && value.size >= 0 ? value.size : 0,
    assetType,
    groupId,
  }
  if (typeof value.used === 'boolean') entry.used = value.used
  return entry
}

function normalizeGroups(value) {
  const groups = Object.create(null)
  if (!value || typeof value !== 'object') return groups
  for (const [id, group] of Object.entries(value)) {
    if (normalizeGroupId(id) !== id || !group || typeof group !== 'object') continue
    groups[id] = {
      name: typeof group.name === 'string' && group.name.trim() ? group.name.trim() : defaultGroupName(id),
      order: Number.isFinite(group.order) ? group.order : Object.keys(groups).length * 10 + 10,
    }
  }
  return groups
}

function ensureGroups(manifest) {
  for (const entry of Object.values(manifest.assets)) {
    if (!Object.hasOwn(manifest.groups, entry.groupId)) {
      manifest.groups[entry.groupId] = {
        name: defaultGroupName(entry.groupId),
        order: Object.keys(manifest.groups).length * 10 + 10,
      }
    }
  }
  return manifest
}

function retainAssetGroups(manifest) {
  const groups = Object.create(null)
  for (const entry of Object.values(manifest.assets)) {
    if (Object.hasOwn(groups, entry.groupId)) continue
    groups[entry.groupId] = manifest.groups[entry.groupId] || {
      name: defaultGroupName(entry.groupId),
      order: Object.keys(groups).length * 10 + 10,
    }
  }
  manifest.groups = groups
  return manifest
}

export function readAssetsManifest(root = process.cwd()) {
  const lockPath = join(root, ASSETS_LOCK_FILE)
  if (!existsSync(lockPath)) return emptyAssetsManifest()
  try {
    const parsed = JSON.parse(readFileSync(lockPath, 'utf8'))
    if (!parsed || typeof parsed !== 'object') throw new Error(`${ASSETS_LOCK_FILE} must contain an object`)
    const isV2 = parsed.version === 2 && parsed.assets && typeof parsed.assets === 'object'
    const sourceAssets = isV2 ? parsed.assets : parsed
    const manifest = {
      version: 2,
      groups: normalizeGroups(isV2 ? parsed.groups : null),
      assets: {},
    }
    for (const [rel, value] of Object.entries(sourceAssets)) {
      const entry = normalizeAssetEntry(rel, value, isV2)
      if (!entry) throw new Error(`invalid asset entry: ${rel}`)
      manifest.assets[rel] = entry
    }
    return ensureGroups(manifest)
  } catch (error) {
    throw new Error(`invalid ${ASSETS_LOCK_FILE}: ${error?.message || error}`)
  }
}

export function readAssetsLock(root = process.cwd()) {
  return readAssetsManifest(root).assets
}

export function writeAssetsManifest(root, manifest) {
  retainAssetGroups(manifest)
  const groups = {}
  const assets = {}
  for (const key of Object.keys(manifest.groups).sort()) groups[key] = manifest.groups[key]
  for (const key of Object.keys(manifest.assets).sort()) assets[key] = manifest.assets[key]
  const output = { version: 2, groups, assets }
  const lockPath = join(root, ASSETS_LOCK_FILE)
  const tmp = `${lockPath}.tmp-${process.pid}`
  try {
    writeFileSync(tmp, `${JSON.stringify(output, null, 2)}\n`)
    renameSync(tmp, lockPath)
  } catch (error) {
    rmSync(tmp, { force: true })
    throw error
  }
  return output
}

export function deleteAsset(root, rel) {
  if (!isSafeAssetRel(root, rel)) throw new Error(`invalid asset path: ${rel}`)
  const manifest = readAssetsManifest(root)
  if (rel.startsWith(`${ASSETS_DIR}/template/`)) {
    throw new Error(`template assets cannot be deleted from a game project: ${rel}`)
  }
  rmSync(join(root, rel), { force: true })
  rmSync(`${join(root, rel)}.import`, { force: true })
  delete manifest.assets[rel]
  writeAssetsManifest(root, manifest)
}

// Only stamped once a sync has completed. Recording it mid-run would clear the
// rollback signal while restores are still pending, so an interrupted hook
// would upload the newer art over the lock it was about to restore.
function stampSyncState(root) {
  writeState(root, {
    assets_head: gitHead(root),
    assets_lock_sha256: currentLockDigest(root),
  })
}

function currentLockDigest(root) {
  try {
    return `sha256:${createHash('sha256').update(readFileSync(join(root, ASSETS_LOCK_FILE))).digest('hex')}`
  } catch {
    return ''
  }
}

function gitHead(root) {
  try {
    return execFileSync('git', ['-C', root, 'rev-parse', 'HEAD'], { encoding: 'utf8', timeout: 30_000 }).trim()
  } catch {
    return ''
  }
}

function isAncestor(root, maybeAncestor, descendant) {
  try {
    execFileSync('git', ['-C', root, 'merge-base', '--is-ancestor', maybeAncestor, descendant], { timeout: 30_000 })
    return true
  } catch {
    return false
  }
}

// Replacing local art is destructive — it is never uploaded, so overwriting it
// loses it for good. Two independent signals must agree: the tracked lock is
// not the one this sandbox wrote, and HEAD has not advanced since. A rollback
// satisfies both; a merge, rebase or pull advances or diverges HEAD and is
// left alone, keeping the agent's newer art.
function rolledBackSinceLastSync(root) {
  const state = readState(root)
  if (!state.assets_lock_sha256 || state.assets_lock_sha256 === currentLockDigest(root)) return false
  const head = gitHead(root)
  if (!state.assets_head || !head) return false
  return head === state.assets_head || isAncestor(root, head, state.assets_head)
}

const REF_SOURCE_EXTS = ['.gd', '.tscn', '.tres', '.godot', '.cfg']

// One pass over the text tree, so marking assets is a Set lookup rather than a
// scan per asset. Paths built at runtime are invisible here — callers must treat
// an unreferenced asset as a hint, never as grounds for dropping it.
function collectResourceRefs(root) {
  const refs = new Set()
  const walk = (dir) => {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      if (entry.isDirectory()) {
        if (!SKIP_DIRS.has(entry.name)) walk(join(dir, entry.name))
        continue
      }
      if (!entry.isFile() || !REF_SOURCE_EXTS.includes(extOf(entry.name))) continue
      let text
      try {
        text = readFileSync(join(dir, entry.name), 'utf8')
      } catch (err) {
        console.log(`[assets] warning: could not scan ${entry.name}: ${err?.message || err}`)
        continue
      }
      // Paths appear inside quoted strings; spaces and parens are legal in them.
      for (const m of text.matchAll(/res:\/\/([^"'\n\r]+)/g)) {
        refs.add(m[1].split('::')[0].trim())
      }
    }
  }
  walk(root)
  return refs
}

export function listLocalAssets(root) {
  const found = []
  const walk = (dir, relDir) => {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const rel = relDir ? `${relDir}/${entry.name}` : entry.name
      if (entry.isDirectory()) {
        if (!SKIP_DIRS.has(entry.name)) walk(join(dir, entry.name), rel)
      } else if (entry.isFile() && ASSET_EXTS.has(extOf(entry.name))) {
        found.push(rel)
      }
    }
  }
  const assetsRoot = join(root, ASSETS_DIR)
  if (existsSync(assetsRoot)) {
    if (lstatSync(assetsRoot).isSymbolicLink()) throw new Error('assets directory must not be a symbolic link')
    walk(assetsRoot, ASSETS_DIR)
  }
  return found.sort()
}

function extOf(name) {
  const i = name.lastIndexOf('.')
  return i < 0 ? '' : name.slice(i).toLowerCase()
}

function loadForgeConfig() {
  let url = process.env.BUILT_IN_FORGE_API_URL || ''
  let key = process.env.BUILT_IN_FORGE_API_KEY || ''
  if (!url || !key) {
    try {
      const env = readFileSync('/opt/.manus/webdev.env', 'utf8')
      for (const line of env.split('\n')) {
        const m = line.match(/^(?:export\s+)?(BUILT_IN_FORGE_API_URL|BUILT_IN_FORGE_API_KEY)=("?)(.*)\2$/)
        if (m) {
          if (m[1] === 'BUILT_IN_FORGE_API_URL' && !url) url = m[3]
          if (m[1] === 'BUILT_IN_FORGE_API_KEY' && !key) key = m[3]
        }
      }
    } catch {
      /* env file absent */
    }
  }
  return { url: url.replace(/\/+$/, ''), key }
}

function downloadFromStorage(root, entry, rel) {
  const directUrl = directAssetUrl(entry)
  let signed = directUrl
  if (!signed) {
    const { url, key } = loadForgeConfig()
    if (!url || !key) throw new Error(`cannot restore ${rel}: storage API not configured`)
    const storageKey = projectStorageKey(entry.path)
    if (!storageKey) throw new Error(`cannot restore ${rel}: invalid storage path`)
    const presign = new URL('v1/storage/presign/get', `${url}/`)
    presign.searchParams.set('path', storageKey)
    const resp = execFileSync('curl', ['-fsS', '-H', `Authorization: Bearer ${key}`, presign.toString()], {
      encoding: 'utf8',
      timeout: 60_000,
    })
    signed = JSON.parse(resp).url
  }
  if (!signed) throw new Error(`cannot restore ${rel}: empty download URL`)
  const target = join(root, rel)
  const tmp = `${target}.download`
  mkdirSync(dirname(target), { recursive: true })
  // A partial file matches no ignore rule and would be committed truncated.
  try {
    const curlFlags = directUrl ? '-fsS' : '-fsSL'
    execFileSync(
      'curl',
      [
        curlFlags,
        '--retry',
        '3',
        '--retry-delay',
        '1',
        '--retry-all-errors',
        '--max-filesize',
        String(MAX_ASSET_SIZE_BYTES),
        '-o',
        tmp,
        signed,
      ],
      { timeout: 10 * 60_000 },
    )
    const gotSize = statSync(tmp).size
    if (gotSize > MAX_ASSET_SIZE_BYTES || (entry.size && gotSize !== entry.size)) {
      throw new Error(`restored ${rel} does not match its recorded size`)
    }
    const gotSha = fileSha256(tmp)
    if (entry.sha256 && gotSha !== entry.sha256) {
      throw new Error(`restored ${rel} does not match its recorded content hash`)
    }
    renameSync(tmp, target)
  } catch (err) {
    rmSync(tmp, { force: true })
    throw err
  }
}

function directAssetUrl(entry) {
  if (typeof entry.path !== 'string') return ''
  try {
    const url = new URL(entry.path)
    if (url.protocol !== 'https:') return ''
    if (!PUBLIC_ASSET_HOSTS.has(url.hostname) && !url.hostname.endsWith('.files.manuscdn.com')) return ''
    return url.toString()
  } catch {
    return ''
  }
}

function projectStorageKey(path) {
  if (typeof path !== 'string' || !path.startsWith('/manus-storage/')) return ''
  const storageKey = path.slice('/manus-storage/'.length)
  if (!storageKey || storageKey.includes('\\')) return ''
  for (const part of storageKey.split('/')) {
    if (!part) return ''
    let decoded
    try {
      decoded = decodeURIComponent(part)
    } catch {
      return ''
    }
    if (!decoded || decoded === '.' || decoded === '..' || decoded.includes('/') || decoded.includes('\\')) return ''
  }
  return storageKey
}

function assetLocation(path) {
  return Boolean(directAssetUrl({ path }) || projectStorageKey(path))
}

export function missingAssets(root = process.cwd()) {
  return absentEntries(root, readAssetsLock(root))
}

function isSafeAssetRel(root, rel) {
  if (!isManagedAssetRel(rel)) return false
  const target = resolve(root, rel)
  if (!target.startsWith(resolve(root) + sep)) return false
  let current = root
  for (const segment of rel.split('/')) {
    current = join(current, segment)
    if (existsSync(current) && lstatSync(current).isSymbolicLink()) return false
  }
  return true
}

function safeLockEntries(root, lock, log = console.log) {
  const keys = Object.keys(lock).filter((rel) => lock[rel] && typeof lock[rel] === 'object')
  const unsafe = keys.filter((rel) => !isSafeAssetRel(root, rel))
  for (const rel of unsafe) {
    log(`[assets] invalid asset path: ${rel}`)
  }
  if (unsafe.length) throw new Error(`invalid asset path in ${ASSETS_LOCK_FILE}: ${unsafe[0]}`)
  return keys
}

function absentEntries(root, lock) {
  return safeLockEntries(root, lock, () => {}).filter((rel) => !existsSync(join(root, rel)))
}

// Restores what the lock records and the disk lacks. Never uploads and never
// deletes lock entries — that bookkeeping belongs to syncAssets.
export function hydrateAssets(root = process.cwd(), log = console.log) {
  const lock = readAssetsManifest(root).assets
  const safe = safeLockEntries(root, lock, log)
  if (!safe.length) return 0
  const targets = absentEntries(root, lock)
  if (!targets.length) return 0
  let hydrated = 0
  for (const rel of targets) {
    log(`[assets] restoring ${rel}...`)
    downloadFromStorage(root, lock[rel], rel)
    hydrated++
  }
  log(`[assets] restored ${hydrated} file(s)`)
  return hydrated
}

// Upload new/changed assets and restore missing tracked assets.
export function syncAssets(root = process.cwd()) {
  const manifest = readAssetsManifest(root)
  const lock = manifest.assets
  const rolledBack = rolledBackSinceLastSync(root)
  const local = listLocalAssets(root)
  for (const rel of safeLockEntries(root, lock)) {
    if (existsSync(join(root, rel)) && !local.includes(rel)) local.push(rel)
  }
  local.sort()
  const localSet = new Set(local)
  let uploaded = 0
  let hydrated = 0

  if (rolledBack) {
    console.log('[assets] rolled back to an earlier version — restoring the tree to match its lock')
  }

  for (const rel of local) {
    const abs = join(root, rel)
    const size = statSync(abs).size
    if (!Number.isSafeInteger(size) || size <= 0 || size > MAX_ASSET_SIZE_BYTES) {
      throw new Error(`asset size is outside the supported range: ${rel}`)
    }
    const sha = fileSha256(abs)
    const entry = lock[rel]
    if (!entry && rel.startsWith(`${ASSETS_DIR}/template/`)) {
      throw new Error(`new project assets must not be added under assets/template: ${rel}`)
    }
    if (entry?.groupId === 'template' && projectStorageKey(entry.path)) {
      entry.groupId = projectGroupId(rel)
    } else if (entry && entry.groupId !== 'template') {
      entry.groupId = rel.startsWith(`${ASSETS_DIR}/template/`)
        ? projectGroupId(rel)
        : defaultGroupId(rel)
    }
    if (entry && entry.sha256 === sha && entry.path) continue
    // Only after a verified rollback: the lock describes the version being
    // restored, so a local file that disagrees is newer art to be replaced.
    if (rolledBack && entry?.path) {
      console.log(`[assets] restoring ${rel} to the rolled-back version...`)
      downloadFromStorage(root, entry, rel)
      hydrated++
      continue
    }
    console.log(`[assets] uploading ${rel}...`)
    lock[rel] = normalizeAssetEntry(rel, {
      groupId: entry?.groupId === 'template' ? projectGroupId(rel) : entry?.groupId,
      path: uploadToStorage(root, abs),
      sha256: sha,
      size,
    })
    uploaded++
    writeAssetsManifest(root, manifest)
  }

  for (const rel of safeLockEntries(root, lock)) {
    if (localSet.has(rel) || existsSync(join(root, rel))) continue
    console.log(`[assets] restoring ${rel}...`)
    downloadFromStorage(root, lock[rel], rel)
    hydrated++
  }

  const refs = collectResourceRefs(root)
  const tracked = safeLockEntries(root, lock, () => {})
  for (const rel of tracked) lock[rel].used = refs.has(rel)
  const unused = tracked.filter((rel) => !lock[rel].used)
  const dangling = [...refs].filter(
    (rel) => rel.startsWith(`${ASSETS_DIR}/`) && ASSET_EXTS.has(extOf(rel)) && !lock[rel] && !existsSync(join(root, rel)),
  )
  if (unused.length) {
    console.log(`[assets] ${unused.length} tracked asset(s) are not referenced: ${unused.slice(0, 5).join(', ')}`)
  }
  if (dangling.length) {
    console.log(`[assets] WARNING: ${dangling.length} reference(s) point at missing art: ${dangling.slice(0, 5).join(', ')}`)
  }

  writeAssetsManifest(root, manifest)
  stampSyncState(root)
  console.log(
    `[assets] in sync: ${Object.keys(lock).length} tracked, ${uploaded} uploaded, ${hydrated} restored`,
  )
  return lock
}

// A silent export would bake a pack with missing art and overwrite a good
// version with it.
export function assertAssetsPresent(root = process.cwd()) {
  const missing = missingAssets(root)
  if (missing.length) {
    const shown = missing.slice(0, 5).join(', ')
    const more = missing.length > 5 ? ` (+${missing.length - 5} more)` : ''
    throw new Error(
      `refusing to export: ${missing.length} asset(s) recorded in ${ASSETS_LOCK_FILE} are missing locally: ${shown}${more}. Save a checkpoint to restore them, or run node scripts/delete-asset.mjs <asset-path>.`,
    )
  }
}

/**
 * Ensure the exported build matches current sources, upload changed
 * artifacts (dedup by content hash), rebuild ./site, persist state.
 * Returns { pck_url, wasm_url, engine_version, source_fingerprint }.
 */
export function prepareArtifacts(root = process.cwd()) {
  // Hold the lock for the whole prepare so no other exporter rewrites dist/.
  acquireExportLockSync(root)
  try {
    return prepareArtifactsLocked(root)
  } finally {
    releaseExportLock(root)
  }
}

function prepareArtifactsLocked(root) {
  // Uploads mutate assets.lock.json, which feeds the fingerprint below.
  syncAssets(root)
  const fingerprint = sourceFingerprint(root)
  const lastBuild = existsSync(join(root, BUILD_FINGERPRINT_FILE))
    ? readFileSync(join(root, BUILD_FINGERPRINT_FILE), 'utf8').trim()
    : ''
  if (lastBuild !== fingerprint || LARGE.some((f) => !existsSync(join(root, 'dist', f)))) {
    console.log('[artifacts] sources changed since last build — re-exporting')
    exportBuild(root, fingerprint)
  } else {
    console.log('[artifacts] build is up to date with sources')
  }

  const state = readState(root)
  const wasmSha = fileSha256(join(root, 'dist', 'index.wasm'))
  const pckSha = fileSha256(join(root, 'dist', 'index.pck'))

  let wasmUrl = state.wasm_sha256 === wasmSha && state.wasm_url ? state.wasm_url : null
  if (wasmUrl) {
    console.log(`[artifacts] engine wasm unchanged — reusing ${wasmUrl}`)
  } else {
    console.log('[artifacts] uploading engine wasm...')
    wasmUrl = uploadToStorage(root, join(root, 'dist', 'index.wasm'))
  }

  let pckUrl = state.pck_sha256 === pckSha && state.pck_url ? state.pck_url : null
  if (pckUrl) {
    console.log(`[artifacts] pck unchanged — reusing ${pckUrl}`)
  } else {
    console.log('[artifacts] uploading game pck...')
    pckUrl = uploadToStorage(root, join(root, 'dist', 'index.pck'))
  }

  const remap = { 'index.wasm': wasmUrl, 'index.pck': pckUrl }
  const siteBytes = assembleSite(root, remap)
  console.log(`[artifacts] site/ assembled (${(siteBytes / 1024).toFixed(0)} KiB)`)

  const artifacts = {
    pck_url: pckUrl,
    wasm_url: wasmUrl,
    engine_version: godotEngineVersion(),
    source_fingerprint: fingerprint,
  }
  writeState(root, { ...artifacts, wasm_sha256: wasmSha, pck_sha256: pckSha })
  return artifacts
}
