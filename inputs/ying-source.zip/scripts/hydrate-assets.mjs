// Restore assets recorded in assets.lock.json but missing on disk.
// Run as its own process so blocking downloads never stall the dev server's
// event loop; server.mjs spawns this before starting an export.
import { hydrateAssets } from './artifacts-lib.mjs'

try {
  hydrateAssets(process.cwd())
} catch (err) {
  console.error(`[assets] restore failed: ${err?.message || err}`)
  process.exit(1)
}
