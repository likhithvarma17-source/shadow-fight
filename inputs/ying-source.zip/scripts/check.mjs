// Keep-alive shim for the project check watcher. The Godot sources have no
// Node type-check step; export errors surface in the dev server output instead.
setInterval(() => {}, 1 << 30)
