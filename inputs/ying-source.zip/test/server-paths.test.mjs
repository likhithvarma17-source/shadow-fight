import assert from 'node:assert/strict'
import { join } from 'node:path'
import test from 'node:test'

import { decodeUrlPath, resolveDistFile } from '../scripts/server-paths.mjs'

test('request paths stay inside the distribution directory', () => {
  const root = '/workspace/game/dist'
  assert.equal(resolveDistFile(root, '/index.html'), join(root, 'index.html'))
  assert.equal(resolveDistFile(root, '/assets/game.js'), join(root, 'assets/game.js'))
  assert.equal(resolveDistFile(root, '/../dist-backup/file'), null)
})

test('invalid request encoding is rejected', () => {
  assert.equal(decodeUrlPath('/%zz'), null)
  assert.equal(decodeUrlPath('/assets%2Fgame.js?cache=1'), '/assets/game.js')
})
