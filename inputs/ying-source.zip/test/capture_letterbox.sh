#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 3 ]]; then
  echo "usage: $0 <width> <height> <output.png>" >&2
  exit 2
fi

WIDTH="$1"
HEIGHT="$2"
OUTPUT="$3"
PROJECT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$(dirname "$OUTPUT")"

godot --audio-driver Dummy --path "$PROJECT" --resolution "${WIDTH}x${HEIGHT}" --position 0,0 res://scenes/game.tscn >"/tmp/zero-hour-letterbox-${WIDTH}x${HEIGHT}.log" 2>&1 &
GAME_PID=$!
cleanup() {
  kill "$GAME_PID" 2>/dev/null || true
  wait "$GAME_PID" 2>/dev/null || true
}
trap cleanup EXIT
sleep 3
ffmpeg -hide_banner -loglevel error -y \
  -f x11grab -video_size "${WIDTH}x${HEIGHT}" -i "${DISPLAY}+0,0" \
  -frames:v 1 "$OUTPUT"
