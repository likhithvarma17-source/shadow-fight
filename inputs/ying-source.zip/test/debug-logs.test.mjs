import assert from 'node:assert/strict'
import { EventEmitter } from 'node:events'
import { mkdtempSync, readFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import test from 'node:test'

import { handleLogPost } from '../scripts/debug-logs.mjs'

function post(root, chunks) {
  const req = new EventEmitter()
  let status = 0
  let body = ''
  const res = {
    writeHead(value) {
      status = value
      return this
    },
    end(value = '') {
      body = value
    },
  }
  handleLogPost(req, res, root)
  for (const chunk of chunks) req.emit('data', chunk)
  req.emit('end')
  return { status, body }
}

test('collector stores all supported log streams', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-debug-logs-'))
  try {
    const payload = Buffer.from(
      JSON.stringify({
        consoleLogs: [{ message: '游戏 ready' }],
        networkRequests: [{ url: '/level.json' }],
        sessionEvents: [{ type: 'click' }],
      }),
    )
    const split = payload.indexOf(Buffer.from('游')) + 1
    const response = post(root, [payload.subarray(0, split), payload.subarray(split)])

    assert.equal(response.status, 200)
    assert.match(readFileSync(join(root, '.manus-logs/browserConsole.log'), 'utf8'), /游戏 ready/)
    assert.match(readFileSync(join(root, '.manus-logs/networkRequests.log'), 'utf8'), /level\.json/)
    assert.match(readFileSync(join(root, '.manus-logs/sessionReplay.log'), 'utf8'), /click/)
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('collector rejects oversized posts', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-debug-logs-limit-'))
  try {
    const response = post(root, [Buffer.alloc(256 * 1024 + 1, 'a')])
    assert.equal(response.status, 413)
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})
