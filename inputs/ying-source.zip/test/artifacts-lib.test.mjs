import assert from 'node:assert/strict'
import { execFileSync, spawn } from 'node:child_process'
import { createHash } from 'node:crypto'
import {
  chmodSync,
  existsSync,
  mkdtempSync,
  mkdirSync,
  readFileSync,
  rmSync,
  symlinkSync,
  truncateSync,
  writeFileSync,
} from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import test from 'node:test'

import {
  defaultGroupId,
  deleteAsset,
  hydrateAssets,
  listLocalAssets,
  missingAssets,
  readAssetsManifest,
  sourceFingerprint,
  syncAssets,
} from '../scripts/artifacts-lib.mjs'

const validSha256 = `sha256:${'a'.repeat(64)}`

test('template assets use the reserved template group', () => {
  assert.equal(defaultGroupId('assets/template/generated/hero.webp'), 'template')
  assert.equal(defaultGroupId('assets/template/hero.webp'), 'template')
  assert.equal(defaultGroupId('assets/generated/hero.webp'), 'generated')
})

test('project assets use their game-defined top-level directory as the group', () => {
  assert.equal(defaultGroupId('assets/heroes/knight/run/frame_01.webp'), 'heroes')
  assert.equal(defaultGroupId('assets/race-tracks/desert/layer.webp'), 'race-tracks')
  assert.equal(defaultGroupId('assets/coin.webp'), 'ungrouped')
  assert.equal(defaultGroupId('assets/角色/hero/run/frame_01.webp'), '角色')
})

test('checkpoint rejects unsupported asset sizes before upload', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-assets-size-'))
  try {
    mkdirSync(join(root, 'assets/characters'), { recursive: true })
    const assetPath = join(root, 'assets/characters/hero.webp')
    writeFileSync(assetPath, '')
    truncateSync(assetPath, 512 * 1024 * 1024 + 1)
    assert.throws(() => syncAssets(root), /asset size is outside the supported range/)
    assert.equal(existsSync(join(root, 'assets.lock.json')), false)
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('capture output directories do not change the source fingerprint', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-artifacts-'))
  try {
    writeFileSync(join(root, 'project.godot'), 'config_version=5\n')
    const initial = sourceFingerprint(root)

    for (const directory of ['test-output', 'game-captures']) {
      const output = join(root, directory)
      mkdirSync(output)
      writeFileSync(join(output, 'capture.png'), `${directory}-capture`)
      assert.equal(sourceFingerprint(root), initial)
    }

    writeFileSync(join(root, 'project.godot'), 'config_version=6\n')
    assert.notEqual(sourceFingerprint(root), initial)
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('asset discovery only includes supported files below assets', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-assets-'))
  try {
    for (const directory of ['assets/images', 'assets/audio', 'assets/video', 'assets/fonts', 'docs']) {
      mkdirSync(join(root, directory), { recursive: true })
    }
    for (const file of [
      'assets/images/hero.webp',
      'assets/audio/theme.ogg',
      'assets/video/intro.webm',
      'assets/fonts/game.ttf',
      'assets/images/hero.webp.import',
      'docs/example.png',
    ]) {
      writeFileSync(join(root, file), file)
    }
    assert.deepEqual(listLocalAssets(root), [
      'assets/audio/theme.ogg',
      'assets/fonts/game.ttf',
      'assets/images/hero.webp',
      'assets/video/intro.webm',
    ])
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('explicit asset deletion removes the file and manifest entry', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-assets-delete-'))
  try {
    mkdirSync(join(root, 'assets/generated'), { recursive: true })
    writeFileSync(join(root, 'assets/generated/hero.webp'), 'hero')
    writeFileSync(join(root, 'assets/generated/hero.webp.import'), 'import')
    writeFileSync(
      join(root, 'assets.lock.json'),
      JSON.stringify({
        version: 2,
        groups: { generated: { name: 'Generated', order: 10 } },
        assets: {
          'assets/generated/hero.webp': {
            assetType: 'image',
            groupId: 'generated',
            path: '/manus-storage/hero',
            sha256: validSha256,
            size: 4,
          },
        },
      }),
    )

    deleteAsset(root, 'assets/generated/hero.webp')

    assert.deepEqual(listLocalAssets(root), [])
    assert.deepEqual(readAssetsManifest(root).assets, {})
    assert.throws(() => deleteAsset(root, '../hero.webp'), /invalid asset path/)
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('explicit asset deletion keeps template assets', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-assets-template-delete-'))
  const rel = 'assets/template/generated/hero.webp'
  try {
    mkdirSync(join(root, 'assets/template/generated'), { recursive: true })
    writeFileSync(join(root, rel), 'hero')
    writeFileSync(
      join(root, 'assets.lock.json'),
      JSON.stringify({
        version: 2,
        groups: { template: { name: 'Template', order: 10 } },
        assets: {
          [rel]: {
            assetType: 'image',
            groupId: 'template',
            path: 'https://files.manuscdn.com/game/1.0.0/hero.webp',
            sha256: validSha256,
            size: 4,
          },
        },
      }),
    )

    assert.throws(() => deleteAsset(root, rel), /template assets cannot be deleted/)
    assert.equal(existsSync(join(root, rel)), true)
    assert.equal(readAssetsManifest(root).assets[rel].groupId, 'template')
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('v1 asset locks normalize to typed v2 entries', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-assets-lock-'))
  try {
    writeFileSync(
      join(root, 'assets.lock.json'),
      JSON.stringify({
        'assets/generated/hero.webp': {
          path: '/manus-storage/hero',
          sha256: validSha256,
          size: 10,
        },
        'assets/audio/theme.ogg': {
          path: '/manus-storage/theme',
          sha256: validSha256,
          size: 20,
        },
      }),
    )
    const manifest = readAssetsManifest(root)
    assert.equal(manifest.version, 2)
    assert.equal(manifest.assets['assets/generated/hero.webp'].assetType, 'image')
    assert.equal(manifest.assets['assets/generated/hero.webp'].groupId, 'generated')
    assert.equal(manifest.assets['assets/audio/theme.ogg'].assetType, 'audio')
    assert.equal(manifest.assets['assets/audio/theme.ogg'].groupId, 'audio')
    assert.equal(manifest.groups.generated.name, 'Generated')
    assert.equal(manifest.groups.audio.name, 'Audio')
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('v2 asset locks preserve custom groups', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-assets-lock-'))
  try {
    writeFileSync(
      join(root, 'assets.lock.json'),
      JSON.stringify({
        version: 2,
        groups: { characters: { name: 'Characters', order: 10 } },
        assets: {
          'assets/generated/hero.webp': {
            assetType: 'image',
            groupId: 'characters',
            path: '/manus-storage/template/hero',
            sha256: validSha256,
            size: 10,
          },
        },
      }),
    )
    const manifest = readAssetsManifest(root)
    assert.equal(manifest.assets['assets/generated/hero.webp'].groupId, 'characters')
    assert.equal(manifest.groups.characters.name, 'Characters')
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('v2 asset locks reject a type that disagrees with the file', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-assets-lock-'))
  try {
    writeFileSync(
      join(root, 'assets.lock.json'),
      JSON.stringify({
        version: 2,
        groups: {},
        assets: {
          'assets/generated/hero.webp': {
            assetType: 'audio',
            groupId: 'generated',
            path: '/manus-storage/project/hero.webp',
            size: 10,
          },
        },
      }),
    )
    assert.throws(() => readAssetsManifest(root), /invalid asset entry/)
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('asset manifests preserve tracked legacy media outside assets', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-assets-lock-'))
  try {
    writeFileSync(
      join(root, 'assets.lock.json'),
      JSON.stringify({
        version: 2,
        groups: {},
        assets: {
          'scripts/replacement.png': {
            assetType: 'image',
            groupId: 'ungrouped',
            path: '/manus-storage/replacement',
            sha256: validSha256,
            size: 10,
          },
        },
      }),
    )
    assert.deepEqual(missingAssets(root), ['scripts/replacement.png'])
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('v2 asset manifests reject invalid content metadata', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-assets-lock-'))
  try {
    const entry = {
      assetType: 'image',
      groupId: 'generated',
      path: '/manus-storage/hero',
      sha256: 'invalid',
      size: 10,
    }
    writeFileSync(
      join(root, 'assets.lock.json'),
      JSON.stringify({ version: 2, groups: {}, assets: { 'assets/generated/hero.webp': entry } }),
    )
    assert.throws(() => readAssetsManifest(root), /invalid asset entry/)

    entry.sha256 = validSha256
    entry.size = 512 * 1024 * 1024 + 1
    writeFileSync(
      join(root, 'assets.lock.json'),
      JSON.stringify({ version: 2, groups: {}, assets: { 'assets/generated/hero.webp': entry } }),
    )
    assert.throws(() => readAssetsManifest(root), /invalid asset entry/)
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('asset discovery rejects a linked assets directory', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-assets-link-'))
  const outside = mkdtempSync(join(tmpdir(), 'game-assets-outside-'))
  try {
    writeFileSync(join(outside, 'private.png'), 'private')
    symlinkSync(outside, join(root, 'assets'))
    assert.throws(() => listLocalAssets(root), /must not be a symbolic link/)
  } finally {
    rmSync(root, { recursive: true, force: true })
    rmSync(outside, { recursive: true, force: true })
  }
})

test('asset manifests reject invalid storage paths', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-assets-lock-'))
  try {
    writeFileSync(
      join(root, 'assets.lock.json'),
      JSON.stringify({
        version: 2,
        groups: {},
        assets: {
          'assets/generated/hero.webp': {
            assetType: 'image',
            groupId: 'generated',
            path: '/manus-storage/%2e%2e/hero.webp',
            size: 10,
          },
        },
      }),
    )
    assert.throws(() => readAssetsManifest(root), /invalid asset entry/)
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('asset manifests accept the public material host and reject lookalike hosts', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-assets-lock-'))
  try {
    const manifest = {
      version: 2,
      groups: {},
      assets: {
        'assets/generated/hero.webp': {
          assetType: 'image',
          groupId: 'generated',
          path: 'https://d1oupeiobkpcny.cloudfront.net/assets/dashboard/materials/hero.webp',
          sha256: validSha256,
          size: 10,
        },
      },
    }
    writeFileSync(join(root, 'assets.lock.json'), JSON.stringify(manifest))
    assert.equal(
      readAssetsManifest(root).assets['assets/generated/hero.webp'].path,
      manifest.assets['assets/generated/hero.webp'].path,
    )

    manifest.assets['assets/generated/hero.webp'].path =
      'https://d1oupeiobkpcny.cloudfront.net.example.com/hero.webp'
    writeFileSync(join(root, 'assets.lock.json'), JSON.stringify(manifest))
    assert.throws(() => readAssetsManifest(root), /invalid asset entry/)
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('asset restore rejects paths through links', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-assets-lock-'))
  const outside = mkdtempSync(join(tmpdir(), 'game-assets-outside-'))
  try {
    mkdirSync(join(root, 'assets'))
    symlinkSync(outside, join(root, 'assets/linked'))
    writeFileSync(
      join(root, 'assets.lock.json'),
      JSON.stringify({
        version: 2,
        groups: {},
        assets: {
          'assets/linked/replacement.png': {
            assetType: 'image',
            groupId: 'linked',
            path: '/manus-storage/replacement',
            sha256: validSha256,
            size: 10,
          },
        },
      }),
    )
    assert.throws(() => missingAssets(root), /invalid asset path/)
  } finally {
    rmSync(root, { recursive: true, force: true })
    rmSync(outside, { recursive: true, force: true })
  }
})

test('template assets restore directly from shared storage', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-assets-hydrate-'))
  const bin = join(root, 'bin')
  const previousPath = process.env.PATH
  const content = 'template hero'
  const sha256 = `sha256:${createHash('sha256').update(content).digest('hex')}`
  try {
    mkdirSync(bin)
    writeFileSync(
      join(root, 'assets.lock.json'),
      JSON.stringify({
        version: 2,
        groups: { generated: { name: 'Generated', order: 10 } },
        assets: {
          'assets/generated/hero.webp': {
            assetType: 'image',
            groupId: 'generated',
            path: 'https://files.manuscdn.com/game/1.0.0/hero.webp',
            sha256,
            size: content.length,
          },
        },
      }),
    )
    const curl = join(bin, 'curl')
    writeFileSync(
      curl,
      `#!/bin/sh
case " $* " in *" --retry 3 "*) ;; *) exit 64 ;; esac
while [ "$1" != "-o" ]; do shift; done
shift
printf "template hero" > "$1"
`,
    )
    chmodSync(curl, 0o755)
    process.env.PATH = `${bin}:${previousPath}`

    assert.equal(hydrateAssets(root, () => {}), 1)
    assert.equal(
      readFileSync(join(root, 'assets/generated/hero.webp'), 'utf8'),
      content,
    )
  } finally {
    process.env.PATH = previousPath
    rmSync(root, { recursive: true, force: true })
  }
})

test('hydrate restores a missing asset even after it was seen', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-assets-hydrate-'))
  const bin = join(root, 'bin')
  const previousPath = process.env.PATH
  const content = 'restored hero'
  const sha256 = `sha256:${createHash('sha256').update(content).digest('hex')}`
  try {
    mkdirSync(bin)
    writeFileSync(
      join(root, 'assets.lock.json'),
      JSON.stringify({
        version: 2,
        groups: { generated: { name: 'Generated', order: 10 } },
        assets: {
          'assets/generated/hero.webp': {
            assetType: 'image',
            groupId: 'generated',
            path: 'https://files.manuscdn.com/game/1.0.0/hero.webp',
            sha256,
            size: content.length,
          },
        },
      }),
    )
    writeFileSync(
      join(root, '.manus-artifacts.json'),
      JSON.stringify({ assets_seen: ['assets/generated/hero.webp'] }),
    )
    const curl = join(bin, 'curl')
    writeFileSync(
      curl,
      '#!/bin/sh\nwhile [ "$1" != "-o" ]; do shift; done\nshift\nprintf "restored hero" > "$1"\n',
    )
    chmodSync(curl, 0o755)
    process.env.PATH = `${bin}:${previousPath}`

    assert.equal(hydrateAssets(root, () => {}), 1)
    assert.equal(
      readFileSync(join(root, 'assets/generated/hero.webp'), 'utf8'),
      content,
    )
  } finally {
    process.env.PATH = previousPath
    rmSync(root, { recursive: true, force: true })
  }
})

test('checkpoint restores a newly added manifest entry', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-assets-sync-'))
  const bin = join(root, 'bin')
  const previousPath = process.env.PATH
  const content = 'new hero'
  const sha256 = `sha256:${createHash('sha256').update(content).digest('hex')}`
  try {
    mkdirSync(bin)
    writeFileSync(
      join(root, 'assets.lock.json'),
      JSON.stringify({
        version: 2,
        groups: { generated: { name: 'Generated', order: 10 } },
        assets: {
          'assets/generated/hero.webp': {
            assetType: 'image',
            groupId: 'generated',
            path: 'https://files.manuscdn.com/game/1.0.0/hero.webp',
            sha256,
            size: content.length,
          },
        },
      }),
    )
    writeFileSync(
      join(root, '.manus-artifacts.json'),
      JSON.stringify({ assets_seen: ['assets/generated/old.webp'] }),
    )
    const curl = join(bin, 'curl')
    writeFileSync(
      curl,
      '#!/bin/sh\nwhile [ "$1" != "-o" ]; do shift; done\nshift\nprintf "new hero" > "$1"\n',
    )
    chmodSync(curl, 0o755)
    process.env.PATH = `${bin}:${previousPath}`

    syncAssets(root)

    assert.equal(
      readFileSync(join(root, 'assets/generated/hero.webp'), 'utf8'),
      content,
    )
  } finally {
    process.env.PATH = previousPath
    rmSync(root, { recursive: true, force: true })
  }
})

test('checkpoint restores an asset missing after a completed sync', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-assets-delete-'))
  const bin = join(root, 'bin')
  const previousPath = process.env.PATH
  const content = 'hero'
  const sha256 = `sha256:${createHash('sha256').update(content).digest('hex')}`
  try {
    mkdirSync(bin)
    writeFileSync(
      join(root, 'assets.lock.json'),
      JSON.stringify({
        version: 2,
        groups: { generated: { name: 'Generated', order: 10 } },
        assets: {
          'assets/generated/hero.webp': {
            assetType: 'image',
            groupId: 'generated',
            path: 'https://files.manuscdn.com/game/1.0.0/hero.webp',
            sha256,
            size: content.length,
          },
        },
      }),
    )
    writeFileSync(
      join(root, '.manus-artifacts.json'),
      JSON.stringify({ assets_seen: ['assets/generated/hero.webp'] }),
    )
    const curl = join(bin, 'curl')
    writeFileSync(
      curl,
      '#!/bin/sh\nwhile [ "$1" != "-o" ]; do shift; done\nshift\nprintf hero > "$1"\n',
    )
    chmodSync(curl, 0o755)
    process.env.PATH = `${bin}:${previousPath}`

    syncAssets(root)

    const manifest = JSON.parse(
      readFileSync(join(root, 'assets.lock.json'), 'utf8'),
    )
    assert.equal(
      readFileSync(join(root, 'assets/generated/hero.webp'), 'utf8'),
      content,
    )
    assert.equal(
      manifest.assets['assets/generated/hero.webp'].path,
      'https://files.manuscdn.com/game/1.0.0/hero.webp',
    )
  } finally {
    process.env.PATH = previousPath
    rmSync(root, { recursive: true, force: true })
  }
})

test('checkpoint writes typed dynamic groups from top-level asset directories', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-assets-sync-'))
  const bin = join(root, 'bin')
  const previousPath = process.env.PATH
  try {
    for (const directory of ['assets/characters/hero/run', 'assets/audio', 'docs', 'bin']) {
      mkdirSync(join(root, directory), { recursive: true })
    }
    writeFileSync(join(root, 'assets/characters/hero/run/frame.webp'), 'hero')
    writeFileSync(join(root, 'assets/audio/theme.ogg'), 'theme')
    writeFileSync(join(root, 'docs/example.png'), 'docs')
    const uploader = join(bin, 'manus-upload-file')
    writeFileSync(uploader, '#!/bin/sh\nprintf "Storage Path: /manus-storage/test/%s\\n" "$(basename "$2")"\n')
    chmodSync(uploader, 0o755)
    process.env.PATH = `${bin}:${previousPath}`

    syncAssets(root)

    const manifest = JSON.parse(readFileSync(join(root, 'assets.lock.json'), 'utf8'))
    assert.equal(manifest.version, 2)
    assert.deepEqual(Object.keys(manifest.assets), [
      'assets/audio/theme.ogg',
      'assets/characters/hero/run/frame.webp',
    ])
    assert.equal(manifest.assets['assets/characters/hero/run/frame.webp'].assetType, 'image')
    assert.equal(manifest.assets['assets/characters/hero/run/frame.webp'].groupId, 'characters')
    assert.equal(manifest.assets['assets/audio/theme.ogg'].assetType, 'audio')
    assert.equal(manifest.assets['assets/audio/theme.ogg'].groupId, 'audio')
    assert.deepEqual(Object.keys(manifest.groups), ['audio', 'characters'])
  } finally {
    process.env.PATH = previousPath
    rmSync(root, { recursive: true, force: true })
  }
})

test('checkpoint migrates old nested groups and removes empty group metadata', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-assets-group-migration-'))
  const rel = 'assets/characters/hero/run/frame.webp'
  const content = 'hero'
  const sha256 = `sha256:${createHash('sha256').update(content).digest('hex')}`
  try {
    mkdirSync(join(root, 'assets/characters/hero/run'), { recursive: true })
    writeFileSync(join(root, rel), content)
    writeFileSync(
      join(root, 'assets.lock.json'),
      JSON.stringify({
        version: 2,
        groups: { run: { name: 'Run', order: 10 } },
        assets: {
          [rel]: {
            assetType: 'image',
            groupId: 'run',
            path: '/manus-storage/test/frame.webp',
            sha256,
            size: content.length,
          },
        },
      }),
    )

    syncAssets(root)

    const manifest = JSON.parse(readFileSync(join(root, 'assets.lock.json'), 'utf8'))
    assert.equal(manifest.assets[rel].groupId, 'characters')
    assert.deepEqual(Object.keys(manifest.groups), ['characters'])
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('checkpoint keeps unchanged template assets and promotes edited ones', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-assets-template-edit-'))
  const bin = join(root, 'bin')
  const previousPath = process.env.PATH
  const unchanged = 'unchanged sky'
  try {
    mkdirSync(join(root, 'assets/template/generated'), { recursive: true })
    mkdirSync(bin)
    writeFileSync(join(root, 'assets/template/generated/hero.webp'), 'edited hero')
    writeFileSync(join(root, 'assets/template/generated/sky.webp'), unchanged)
    writeFileSync(
      join(root, 'assets.lock.json'),
      JSON.stringify({
        version: 2,
        groups: { template: { name: 'Template', order: 10 } },
        assets: {
          'assets/template/generated/hero.webp': {
            assetType: 'image',
            groupId: 'template',
            path: 'https://files.manuscdn.com/game/1.0.0/hero.webp',
            sha256: validSha256,
            size: 4,
          },
          'assets/template/generated/sky.webp': {
            assetType: 'image',
            groupId: 'template',
            path: 'https://files.manuscdn.com/game/1.0.0/sky.webp',
            sha256: `sha256:${createHash('sha256').update(unchanged).digest('hex')}`,
            size: unchanged.length,
          },
        },
      }),
    )
    const uploader = join(bin, 'manus-upload-file')
    writeFileSync(
      uploader,
      '#!/bin/sh\nprintf "Storage Path: /manus-storage/project/%s\\n" "$(basename "$2")"\n',
    )
    chmodSync(uploader, 0o755)
    process.env.PATH = `${bin}:${previousPath}`

    syncAssets(root)

    const manifest = JSON.parse(
      readFileSync(join(root, 'assets.lock.json'), 'utf8'),
    )
    assert.equal(
      manifest.assets['assets/template/generated/hero.webp'].path,
      '/manus-storage/project/hero.webp',
    )
    assert.equal(
      manifest.assets['assets/template/generated/hero.webp'].groupId,
      'generated',
    )
    assert.equal(
      manifest.assets['assets/template/generated/sky.webp'].path,
      'https://files.manuscdn.com/game/1.0.0/sky.webp',
    )
    assert.equal(
      manifest.assets['assets/template/generated/sky.webp'].groupId,
      'template',
    )
  } finally {
    process.env.PATH = previousPath
    rmSync(root, { recursive: true, force: true })
  }
})

test('checkpoint rejects new project assets under the template directory', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-assets-template-new-'))
  try {
    mkdirSync(join(root, 'assets/template/generated'), { recursive: true })
    writeFileSync(join(root, 'assets/template/generated/new.webp'), 'new project art')
    assert.throws(
      () => syncAssets(root),
      /new project assets must not be added under assets\/template/,
    )
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('template publisher writes shared typed entries', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-template-assets-'))
  const bin = join(root, 'bin')
  try {
    mkdirSync(join(root, 'assets/template/environment'), { recursive: true })
    mkdirSync(bin)
    writeFileSync(join(root, 'assets/template/environment/sky.webp'), 'sky')
    const uploader = join(bin, 'publish-template-asset')
    writeFileSync(
      uploader,
      '#!/bin/sh\nprintf "CDN URL: https://files.manuscdn.com/templates/%s/%s/%s\\n" "$2" "$3" "$4"\n',
    )
    chmodSync(uploader, 0o755)
    const curl = join(bin, 'curl')
    writeFileSync(
      curl,
      '#!/bin/sh\nwhile [ "$1" != "-o" ]; do shift; done\nshift\nprintf sky > "$1"\n',
    )
    chmodSync(curl, 0o755)

    execFileSync('node', [join(import.meta.dirname, '../../../scripts/publish-game-template-assets.mjs')], {
      env: {
        ...process.env,
        PATH: `${bin}:${process.env.PATH}`,
        GAME_TEMPLATE_ASSET_UPLOAD_COMMAND: uploader,
        GAME_TEMPLATE_ROOT: root,
        GAME_TEMPLATE_VERSION: '1.0.0',
      },
    })

    const manifest = JSON.parse(readFileSync(join(root, 'assets.lock.json'), 'utf8'))
    assert.deepEqual(manifest.groups.template, { name: 'Template', order: 10 })
    assert.equal(manifest.assets['assets/template/environment/sky.webp'].assetType, 'image')
    assert.equal(manifest.assets['assets/template/environment/sky.webp'].groupId, 'template')
    assert.equal(
      manifest.assets['assets/template/environment/sky.webp'].path,
      'https://files.manuscdn.com/templates/game/1.0.0/assets/template/environment/sky.webp',
    )
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('template publisher validates an existing version from a clean checkout', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-template-assets-'))
  const bin = join(root, 'bin')
  const content = 'sky'
  const digest = createHash('sha256').update(content).digest('hex')
  const rel = 'assets/template/environment/sky.webp'
  try {
    mkdirSync(bin)
    writeFileSync(
      join(root, 'assets.lock.json'),
      JSON.stringify({
        version: 2,
        groups: { template: { name: 'Template', order: 10 } },
        assets: {
          [rel]: {
            assetType: 'image',
            groupId: 'template',
            path: `https://d1oupeiobkpcny.cloudfront.net/assets/dashboard/materials/2026/08/28/${digest}.webp`,
            sha256: `sha256:${digest}`,
            size: content.length,
          },
        },
      }),
    )
    const curl = join(bin, 'curl')
    writeFileSync(
      curl,
      '#!/bin/sh\nwhile [ "$1" != "-o" ]; do shift; done\nshift\nprintf sky > "$1"\n',
    )
    chmodSync(curl, 0o755)

    execFileSync('node', [join(import.meta.dirname, '../../../scripts/publish-game-template-assets.mjs')], {
      env: {
        ...process.env,
        PATH: `${bin}:${process.env.PATH}`,
        GAME_TEMPLATE_ROOT: root,
        GAME_TEMPLATE_VERSION: '1.0.0',
      },
    })

    assert.equal(existsSync(join(root, rel)), false)
    const manifest = JSON.parse(readFileSync(join(root, 'assets.lock.json'), 'utf8'))
    assert.equal(manifest.assets[rel].path.endsWith(`/${digest}.webp`), true)
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('template publisher uploads through the admin batch API', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-template-assets-'))
  const bin = join(root, 'bin')
  const ready = join(root, 'server-port')
  const serverFile = join(root, 'server.mjs')
  const headersFile = join(root, 'headers.json')
  let server
  try {
    mkdirSync(join(root, 'assets/template/environment'), { recursive: true })
    mkdirSync(bin)
    writeFileSync(join(root, 'assets/template/environment/sky.webp'), 'sky')
    const digest = createHash('sha256').update('sky').digest('hex')
    const attempts = join(root, 'curl-attempts')
    const curl = join(bin, 'curl')
    writeFileSync(
      curl,
      `#!/bin/sh
if [ ! -f '${attempts}' ]; then
  touch '${attempts}'
  exit 22
fi
while [ "$1" != "-o" ]; do shift; done
shift
printf sky > "$1"
`,
    )
    chmodSync(curl, 0o755)
    writeFileSync(headersFile, JSON.stringify({ 'x-test': 'local' }))
    writeFileSync(
      serverFile,
      `import { writeFileSync } from 'node:fs'
import http from 'node:http'
const files = new Map()
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://127.0.0.1')
  if (req.method === 'POST' && url.pathname === '/file.v1.AdminFileService/AdminBatchSignUrl') {
    if (req.headers['x-test'] !== 'local') { res.writeHead(401).end(); return }
    const chunks = []
    for await (const chunk of req) chunks.push(chunk)
    const body = JSON.parse(Buffer.concat(chunks))
    if (body.urls?.some((item) => item.module !== 'ADMIN_PRE_SIGN_MODULE_MATERIALS')) {
      res.writeHead(400).end(); return
    }
    const port = server.address().port
    const signUrlList = body.urls.map(({ filename }) => ({
      filename,
      preSignUrl: \`http://127.0.0.1:\${port}/upload?name=\${encodeURIComponent(filename)}\`,
      objectUrl: \`http://127.0.0.1:\${port}/object?name=\${encodeURIComponent(filename)}\`,
      cdnUrl: \`https://d1oupeiobkpcny.cloudfront.net/assets/dashboard/materials/2026/08/27/\${filename.split('/').map(encodeURIComponent).join('/')}?signed=local\`,
    }))
    res.setHeader('content-type', 'application/json')
    res.end(JSON.stringify({ signUrlList }))
    return
  }
  const name = url.searchParams.get('name')
  if (req.method === 'PUT' && url.pathname === '/upload' && name) {
    if (req.headers['content-type'] !== 'image/webp') { res.writeHead(415).end(); return }
    const chunks = []
    for await (const chunk of req) chunks.push(chunk)
    files.set(name, Buffer.concat(chunks))
    res.writeHead(200).end()
    return
  }
  if (req.method === 'GET' && url.pathname === '/object' && files.has(name)) {
    res.writeHead(200).end(files.get(name))
    return
  }
  res.writeHead(404).end()
})
server.listen(0, '127.0.0.1', () => writeFileSync(process.argv[2], String(server.address().port)))
`,
    )
    server = spawn(process.execPath, [serverFile, ready], { stdio: 'ignore' })
    const waitBuffer = new Int32Array(new SharedArrayBuffer(4))
    for (let i = 0; i < 200 && !existsSync(ready); i += 1) Atomics.wait(waitBuffer, 0, 0, 10)
    assert.equal(existsSync(ready), true)
    const port = readFileSync(ready, 'utf8')

    execFileSync('node', [join(import.meta.dirname, '../../../scripts/publish-game-template-assets.mjs')], {
      env: {
        ...process.env,
        PATH: `${bin}:${process.env.PATH}`,
        GAME_TEMPLATE_ADMIN_API_URL: `http://127.0.0.1:${port}/file.v1.AdminFileService/AdminBatchSignUrl`,
        GAME_TEMPLATE_ADMIN_HEADERS_FILE: headersFile,
        GAME_TEMPLATE_ROOT: root,
        GAME_TEMPLATE_VERSION: '1.0.0',
      },
    })

    const manifest = JSON.parse(readFileSync(join(root, 'assets.lock.json'), 'utf8'))
    assert.equal(
      manifest.assets['assets/template/environment/sky.webp'].path,
      `https://d1oupeiobkpcny.cloudfront.net/assets/dashboard/materials/2026/08/27/game-template/game/1.0.0/${digest}/assets/template/environment/sky.webp`,
    )
  } finally {
    server?.kill()
    rmSync(root, { recursive: true, force: true })
  }
})

test('template publisher only accepts the admin batch endpoint', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-template-assets-'))
  try {
    mkdirSync(join(root, 'assets/template/environment'), { recursive: true })
    writeFileSync(join(root, 'assets/template/environment/sky.webp'), 'sky')
    assert.throws(
      () =>
        execFileSync('node', [join(import.meta.dirname, '../../../scripts/publish-game-template-assets.mjs')], {
          env: {
            ...process.env,
            GAME_TEMPLATE_ADMIN_API_URL:
              'https://admin.example.com/file.v1.AdminFileService/AdminSignUrl',
            GAME_TEMPLATE_ROOT: root,
            GAME_TEMPLATE_VERSION: '1.0.0',
          },
          stdio: 'pipe',
        }),
      /must target AdminBatchSignUrl/,
    )
    assert.throws(
      () =>
        execFileSync('node', [join(import.meta.dirname, '../../../scripts/publish-game-template-assets.mjs')], {
          env: {
            ...process.env,
            GAME_TEMPLATE_ADMIN_API_URL:
              'https://example.com/file.v1.AdminFileService/AdminBatchSignUrl',
            GAME_TEMPLATE_ROOT: root,
            GAME_TEMPLATE_VERSION: '1.0.0',
          },
          stdio: 'pipe',
        }),
      /must target AdminBatchSignUrl/,
    )
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('template publisher requires a new version when the asset set changes', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-template-assets-'))
  const uploader = join(root, 'publish-template-asset')
  const sky = 'sky'
  try {
    mkdirSync(join(root, 'assets/template/environment'), { recursive: true })
    writeFileSync(join(root, 'assets/template/environment/sky.webp'), sky)
    writeFileSync(join(root, 'assets/template/environment/new.webp'), 'new')
    writeFileSync(
      join(root, 'assets.lock.json'),
      JSON.stringify({
        version: 2,
        groups: { template: { name: 'Template', order: 10 } },
        assets: {
          'assets/template/environment/sky.webp': {
            assetType: 'image',
            groupId: 'template',
            path: 'https://files.manuscdn.com/templates/game/1.0.0/assets/template/environment/sky.webp',
            sha256: `sha256:${createHash('sha256').update(sky).digest('hex')}`,
            size: sky.length,
          },
        },
      }),
    )
    writeFileSync(uploader, '#!/bin/sh\nexit 0\n')
    chmodSync(uploader, 0o755)
    assert.throws(
      () =>
        execFileSync('node', [join(import.meta.dirname, '../../../scripts/publish-game-template-assets.mjs')], {
          env: {
            ...process.env,
            GAME_TEMPLATE_ASSET_UPLOAD_COMMAND: uploader,
            GAME_TEMPLATE_ROOT: root,
            GAME_TEMPLATE_VERSION: '1.0.0',
          },
          stdio: 'pipe',
        }),
      /template version asset set changed/,
    )

    rmSync(join(root, 'assets/template/environment/new.webp'))
    rmSync(join(root, 'assets/template/environment/sky.webp'))
    writeFileSync(join(root, 'assets/template/environment/replacement.webp'), 'replacement')
    assert.throws(
      () =>
        execFileSync('node', [join(import.meta.dirname, '../../../scripts/publish-game-template-assets.mjs')], {
          env: {
            ...process.env,
            GAME_TEMPLATE_ASSET_UPLOAD_COMMAND: uploader,
            GAME_TEMPLATE_ROOT: root,
            GAME_TEMPLATE_VERSION: '1.0.0',
          },
          stdio: 'pipe',
        }),
      /template version asset set changed/,
    )
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('template publisher refuses an empty asset tree', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-template-assets-'))
  const uploader = join(root, 'publish-template-asset')
  try {
    writeFileSync(uploader, '#!/bin/sh\nexit 0\n')
    chmodSync(uploader, 0o755)
    assert.throws(
      () =>
        execFileSync('node', [join(import.meta.dirname, '../../../scripts/publish-game-template-assets.mjs')], {
          env: {
            ...process.env,
            GAME_TEMPLATE_ASSET_UPLOAD_COMMAND: uploader,
            GAME_TEMPLATE_ROOT: root,
            GAME_TEMPLATE_VERSION: '1.0.0',
          },
          stdio: 'pipe',
        }),
      /template assets directory is empty/,
    )
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('template publisher rejects a URL for a different relative path', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-template-assets-'))
  const uploader = join(root, 'publish-template-asset')
  try {
    mkdirSync(join(root, 'assets/template/environment'), { recursive: true })
    writeFileSync(join(root, 'assets/template/environment/sky.webp'), 'sky')
    writeFileSync(
      uploader,
      '#!/bin/sh\nprintf "CDN URL: https://files.manuscdn.com/templates/%s/%s/sky.webp\\n" "$2" "$3"\n',
    )
    chmodSync(uploader, 0o755)
    assert.throws(
      () =>
        execFileSync('node', [join(import.meta.dirname, '../../../scripts/publish-game-template-assets.mjs')], {
          env: {
            ...process.env,
            GAME_TEMPLATE_ASSET_UPLOAD_COMMAND: uploader,
            GAME_TEMPLATE_ROOT: root,
            GAME_TEMPLATE_VERSION: '1.0.0',
          },
        }),
      /could not parse template asset URL/,
    )
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('template publisher rejects source assets outside the template directory', () => {
  const root = mkdtempSync(join(tmpdir(), 'game-template-assets-'))
  const uploader = join(root, 'publish-template-asset')
  try {
    mkdirSync(join(root, 'assets/generated'), { recursive: true })
    writeFileSync(join(root, 'assets/generated/hero.webp'), 'hero')
    writeFileSync(uploader, '#!/bin/sh\nexit 0\n')
    chmodSync(uploader, 0o755)
    assert.throws(
      () =>
        execFileSync('node', [join(import.meta.dirname, '../../../scripts/publish-game-template-assets.mjs')], {
          env: {
            ...process.env,
            GAME_TEMPLATE_ASSET_UPLOAD_COMMAND: uploader,
            GAME_TEMPLATE_ROOT: root,
            GAME_TEMPLATE_VERSION: '1.0.0',
          },
        }),
      /outside assets\/template/,
    )
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})
