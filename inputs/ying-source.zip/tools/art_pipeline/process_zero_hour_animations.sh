#!/usr/bin/env bash
set -euo pipefail

PROJECT="$(cd "$(dirname "$0")/../.." && pwd)"
SOURCE="${ZERO_HOUR_ART_SOURCE:-$PROJECT/../zero-hour-art-sources}"
EXTRACT_TOOL="$PROJECT/tools/art_pipeline/extract_video_frames.py"
PROCESS_TOOL="$PROJECT/tools/art_pipeline/process_animation_frames.py"
REMOVE_TOOL="$PROJECT/tools/art_pipeline/remove_image_background.py"
REQ="$PROJECT/tools/art_pipeline/requirements.txt"

rm -rf "$SOURCE/scaled" "$SOURCE/extracted"
mkdir -p "$SOURCE/scaled" "$SOURCE/extracted" \
  "$PROJECT/assets/characters/hero" \
  "$PROJECT/assets/characters/blade_guard" \
  "$PROJECT/assets/characters/gunner"

process_clip() {
  local clip="$1" fps="$2" target="$3" prefix="$4" start="$5" duration="$6"
  rm -rf "$SOURCE/extracted/$clip" "$target"
  mkdir -p "$SOURCE/extracted/$clip" "$target"
  ffmpeg -hide_banner -loglevel error -y -i "$SOURCE/$clip.mp4" \
    -vf "scale=640:360:flags=lanczos" -an -c:v libx264 -crf 18 -preset fast \
    "$SOURCE/scaled/$clip.mp4"
  uv run python "$EXTRACT_TOOL" "$SOURCE/scaled/$clip.mp4" "$SOURCE/extracted/$clip" \
    --fps "$fps" --start "$start" --duration "$duration" --prefix frame
  uv run --with-requirements "$REQ" python "$PROCESS_TOOL" \
    "$SOURCE/extracted/$clip" "$target" --pattern 'frame_*.png' \
    --prefix "$prefix" --canvas 192 --content 176
}

process_idle() {
  local name="$1" reference="$2" target="$3" prefix="$4"
  rm -rf "$SOURCE/extracted/$name" "$target"
  mkdir -p "$SOURCE/extracted/$name" "$target"
  ffmpeg -hide_banner -loglevel error -y -i "$reference" -vf "scale=640:360:flags=lanczos" \
    "$SOURCE/extracted/$name/frame_0000.png"
  uv run --with-requirements "$REQ" python "$REMOVE_TOOL" \
    "$SOURCE/extracted/$name/frame_0000.png" "$SOURCE/extracted/$name/cutout_preview.webp"
  uv run --with-requirements "$REQ" python "$PROCESS_TOOL" \
    "$SOURCE/extracted/$name" "$target" --pattern 'frame_*.png' \
    --prefix "$prefix" --canvas 192 --content 176
}

process_idle hero_idle "$SOURCE/hero_reference.png" "$PROJECT/assets/characters/hero/idle" idle
process_clip hero_run 8 "$PROJECT/assets/characters/hero/run" run 0.55 1.6
process_clip hero_jump 4 "$PROJECT/assets/characters/hero/jump" jump 0.45 3.0
process_clip hero_attack 4 "$PROJECT/assets/characters/hero/attack" attack 0.45 3.0
process_clip hero_death 4 "$PROJECT/assets/characters/hero/death" death 0.45 3.0

process_idle blade_idle "$SOURCE/blade_enemy_reference.png" "$PROJECT/assets/characters/blade_guard/idle" idle
process_clip blade_run 8 "$PROJECT/assets/characters/blade_guard/run" run 0.55 1.6
process_clip blade_attack 4 "$PROJECT/assets/characters/blade_guard/attack" attack 0.45 3.0
process_clip blade_death 4 "$PROJECT/assets/characters/blade_guard/death" death 0.45 3.0

process_idle gunner_idle "$SOURCE/gunner_enemy_reference.png" "$PROJECT/assets/characters/gunner/idle" idle
process_clip gunner_walk 8 "$PROJECT/assets/characters/gunner/walk" walk 0.55 1.6
process_clip gunner_shoot 4 "$PROJECT/assets/characters/gunner/shoot" shoot 0.45 3.0
process_clip gunner_death 4 "$PROJECT/assets/characters/gunner/death" death 0.45 3.0

python3 "$PROJECT/tools/art_pipeline/generate_zero_hour_manifest.py"
python3 "$PROJECT/tools/art_pipeline/optimize_zero_hour_imports.py"
