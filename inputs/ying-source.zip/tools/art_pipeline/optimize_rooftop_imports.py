from __future__ import annotations

import re
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[2]
ROOT = PROJECT / "assets" / "environment"
changed = 0

for sidecar in sorted(ROOT.glob("*.webp.import")):
    text = sidecar.read_text(encoding="utf-8")
    updated = re.sub(r"compress/mode=\d+", "compress/mode=1", text)
    updated = re.sub(r"compress/lossy_quality=[0-9.]+", "compress/lossy_quality=0.74", updated)
    if updated != text:
        sidecar.write_text(updated, encoding="utf-8")
        changed += 1
        print(f"[ENV_IMPORT_OPTIMIZED] {sidecar.relative_to(PROJECT)}")

print(f"[ENV_IMPORT_OPTIMIZER_PASS] changed={changed}")
