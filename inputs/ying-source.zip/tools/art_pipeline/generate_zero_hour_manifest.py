from pathlib import Path

project = Path(__file__).resolve().parents[2]
assets = project / 'assets' / 'characters'
out = project / 'scripts' / 'animation_frames.gd'
sets = {
    'HERO_IDLE': assets / 'hero' / 'idle',
    'HERO_RUN': assets / 'hero' / 'run',
    'HERO_JUMP': assets / 'hero' / 'jump',
    'HERO_ATTACK': assets / 'hero' / 'attack',
    'HERO_DEATH': assets / 'hero' / 'death',
    'BLADE_IDLE': assets / 'blade_guard' / 'idle',
    'BLADE_RUN': assets / 'blade_guard' / 'run',
    'BLADE_ATTACK': assets / 'blade_guard' / 'attack',
    'BLADE_DEATH': assets / 'blade_guard' / 'death',
    'GUNNER_IDLE': assets / 'gunner' / 'idle',
    'GUNNER_WALK': assets / 'gunner' / 'walk',
    'GUNNER_SHOOT': assets / 'gunner' / 'shoot',
    'GUNNER_DEATH': assets / 'gunner' / 'death',
}

lines = [
    'class_name NeonAnimationFrames',
    'extends RefCounted',
    '',
    '# Generated from reference-guided video clips by the documented art pipeline.',
    '# Literal preloads keep every runtime frame discoverable by the Web exporter.',
    '',
]
for name, directory in sets.items():
    frames = sorted(directory.glob('*.webp'))
    if not frames:
        raise RuntimeError(f'No frames found for {name}: {directory}')
    lines.append(f'const {name} = [')
    for frame in frames:
        resource_path = 'res://' + frame.relative_to(project).as_posix()
        lines.append(f'\tpreload("{resource_path}"),')
    lines.extend([']', ''])

out.write_text('\n'.join(lines), encoding='utf-8')
print(f'Wrote {out} with {sum(len(list(path.glob("*.webp"))) for path in sets.values())} literal preloads')
