#!/usr/bin/env python3
"""Prepare generated 16:9 post-boss comic panels for Godot Web runtime."""

from __future__ import annotations

import argparse
from pathlib import Path

from PIL import Image

TARGET_SIZE = (1280, 720)
FILENAMES = (
    "panel_01_warehouse.png",
    "panel_02_crate.png",
    "panel_03_blade.png",
    "panel_04_cat.png",
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_dir", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--quality", type=int, default=76)
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    for filename in FILENAMES:
        source = args.input_dir / filename
        if not source.is_file():
            raise FileNotFoundError(source)
        with Image.open(source) as image:
            image = image.convert("RGB")
            if image.width * 9 != image.height * 16:
                raise ValueError(f"expected 16:9 source, got {image.size}: {source}")
            image = image.resize(TARGET_SIZE, Image.Resampling.LANCZOS)
            destination = args.output_dir / (source.stem + ".webp")
            image.save(destination, "WEBP", quality=args.quality, method=6)
            with Image.open(destination) as check:
                if check.size != TARGET_SIZE:
                    raise RuntimeError(f"unexpected runtime size for {destination}: {check.size}")
            print(f"{destination} {destination.stat().st_size} bytes")


if __name__ == "__main__":
    main()
