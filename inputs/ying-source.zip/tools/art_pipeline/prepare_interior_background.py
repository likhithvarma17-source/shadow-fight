#!/usr/bin/env python3
"""Resize and WebP-optimize the selected 9:16 hideout plate for Godot Web."""

from pathlib import Path
import sys
from PIL import Image, ImageEnhance


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: prepare_interior_background.py INPUT OUTPUT")
    source = Path(sys.argv[1])
    target = Path(sys.argv[2])
    target.parent.mkdir(parents=True, exist_ok=True)
    image = Image.open(source).convert("RGB")
    image = image.resize((900, 1600), Image.Resampling.LANCZOS)
    image = ImageEnhance.Brightness(image).enhance(1.07)
    image = ImageEnhance.Contrast(image).enhance(0.94)
    image.save(target, "WEBP", quality=73, method=6)
    print(f"prepared {target}: {target.stat().st_size} bytes, {image.size[0]}x{image.size[1]}")


if __name__ == "__main__":
    main()
