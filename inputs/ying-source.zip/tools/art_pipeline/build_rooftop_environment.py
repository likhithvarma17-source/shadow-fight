from __future__ import annotations

import os
import runpy
from pathlib import Path

import numpy as np
from PIL import Image

PROJECT = Path(__file__).resolve().parents[2]
SOURCE = Path(os.environ.get("ZERO_HOUR_ENV_SOURCE", "/home/ubuntu/zero-hour-environment-sources"))
OUTPUT = PROJECT / "assets" / "environment"
OUTPUT.mkdir(parents=True, exist_ok=True)


def recover_alpha(path: Path) -> Image.Image:
    rgb = np.asarray(Image.open(path).convert("RGB"), dtype=np.float32)
    high = rgb.max(axis=2)
    low = rgb.min(axis=2)
    chroma = high - low
    luminance = rgb.mean(axis=2)

    # Image generation sometimes bakes a neutral white/light-gray checkerboard
    # despite requesting alpha. Remove only bright neutral pixels; the authored
    # environment is dark blue-black, so wet cyan highlights remain intact.
    neutral_weight = np.clip((24.0 - chroma) / 24.0, 0.0, 1.0)
    bright_weight = np.clip((luminance - 178.0) / 54.0, 0.0, 1.0)
    alpha = 1.0 - neutral_weight * bright_weight
    alpha = np.where((luminance > 226.0) & (chroma < 30.0), 0.0, alpha)
    alpha = np.clip(alpha * 255.0, 0.0, 255.0).astype(np.uint8)

    rgba = np.dstack((rgb.astype(np.uint8), alpha))
    return trim_alpha(Image.fromarray(rgba, "RGBA"))


def trim_alpha(image: Image.Image, threshold: int = 5, margin: int = 4) -> Image.Image:
    alpha = np.asarray(image.getchannel("A"))
    ys, xs = np.where(alpha > threshold)
    if xs.size == 0 or ys.size == 0:
        raise RuntimeError("Asset became fully transparent")
    left = max(0, int(xs.min()) - margin)
    top = max(0, int(ys.min()) - margin)
    right = min(image.width, int(xs.max()) + margin + 1)
    bottom = min(image.height, int(ys.max()) + margin + 1)
    return image.crop((left, top, right, bottom))


def exact_resize(image: Image.Image, size: tuple[int, int]) -> Image.Image:
    return image.resize(size, Image.Resampling.LANCZOS)


def contain(image: Image.Image, size: tuple[int, int]) -> Image.Image:
    result = Image.new("RGBA", size, (0, 0, 0, 0))
    copy = image.copy()
    copy.thumbnail(size, Image.Resampling.LANCZOS)
    x = (size[0] - copy.width) // 2
    y = size[1] - copy.height
    result.alpha_composite(copy, (x, y))
    return result


def save_webp(image: Image.Image, name: str) -> None:
    output = OUTPUT / name
    image.save(output, "WEBP", quality=82, method=6, lossless=False, exact=True)
    print(f"[ENV_ASSET] {output.relative_to(PROJECT)} {image.width}x{image.height} {output.stat().st_size} bytes")


roof = recover_alpha(SOURCE / "roof_surface.png")
# Use a center section without generated end caps so the ground repeats cleanly.
center_left = int(roof.width * 0.16)
center_right = int(roof.width * 0.84)
roof_center = trim_alpha(roof.crop((center_left, 0, center_right, roof.height)))
ground_tile = exact_resize(roof_center, (640, 90))
save_webp(ground_tile, "roof_ground_tile.webp")
save_webp(ground_tile.transpose(Image.Transpose.FLIP_LEFT_RIGHT), "roof_ground_tile_b.webp")

catwalk = recover_alpha(SOURCE / "catwalk_platform.png")
save_webp(exact_resize(catwalk, (320, 30)), "catwalk_platform.webp")

machine = recover_alpha(SOURCE / "rooftop_machine.png")
left_machine = trim_alpha(machine.crop((0, 0, int(machine.width * 0.64), machine.height)))
right_machine = trim_alpha(machine.crop((int(machine.width * 0.48), 0, machine.width, machine.height)))
save_webp(contain(left_machine, (220, 150)), "rooftop_machine_a.webp")
save_webp(contain(right_machine, (170, 140)), "rooftop_machine_b.webp")

gate = recover_alpha(SOURCE / "exit_gate.png")
save_webp(contain(gate, (120, 210)), "exit_gate.webp")

optimizer = Path(__file__).with_name("optimize_rooftop_imports.py")
if optimizer.exists():
    runpy.run_path(str(optimizer), run_name="__main__")

print("[ENVIRONMENT_ASSETS_PASS]")
