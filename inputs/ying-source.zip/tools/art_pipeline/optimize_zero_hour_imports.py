from pathlib import Path
import re

project = Path(__file__).resolve().parents[2]
root = project / 'assets' / 'characters'
changed = 0
for path in sorted(root.rglob('*.webp.import')):
    text = path.read_text(encoding='utf-8')
    updated = re.sub(r'^compress/mode=.*$', 'compress/mode=1', text, flags=re.MULTILINE)
    updated = re.sub(
        r'^compress/lossy_quality=.*$',
        'compress/lossy_quality=0.78',
        updated,
        flags=re.MULTILINE,
    )
    if updated != text:
        path.write_text(updated, encoding='utf-8')
        changed += 1
print(f'Updated {changed} animation texture import sidecars')
