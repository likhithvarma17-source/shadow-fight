#!/usr/bin/env python3
"""Resize a 16:9 generated briefing plate to the exact Godot viewport and WebP-optimize it."""

from __future__ import annotations

import argparse
from pathlib import Path

from PIL import Image

TARGET_SIZE = (1280, 720)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--quality", type=int, default=82)
    args = parser.parse_args()

    with Image.open(args.input) as source:
        source = source.convert("RGB")
        if source.width * 9 != source.height * 16:
            raise ValueError(f"Expected a 16:9 source, got {source.width}x{source.height}")
        result = source.resize(TARGET_SIZE, Image.Resampling.LANCZOS)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        result.save(args.output, "WEBP", quality=args.quality, method=6, exact=True)

    with Image.open(args.output) as check:
        if check.size != TARGET_SIZE:
            raise RuntimeError(f"Unexpected output size: {check.size}")

    print(f"[BRIEFING_BG_PASS] {args.output} {TARGET_SIZE[0]}x{TARGET_SIZE[1]} {args.output.stat().st_size} bytes")


if __name__ == "__main__":
    main()
