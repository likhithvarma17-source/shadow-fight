#!/usr/bin/env bash
set -euo pipefail

PROJECT="$(cd "$(dirname "$0")/../.." && pwd)"
SOURCE="${ZERO_HOUR_AUDIO_SOURCE:-$PROJECT/../zero-hour-audio-sources}"
BGM_SOURCE="${ZERO_HOUR_BGM_SOURCE:-$SOURCE/zero_hour_bgm_lofi_radio_a.mp3}"
SLASH_SOURCE="${ZERO_HOUR_SLASH_SOURCE:-$SOURCE/eleven_labs_slash.wav}"
PARRY_SOURCE="${ZERO_HOUR_PARRY_SOURCE:-$SOURCE/eleven_labs_parry.wav}"
ENEMY_HIT_SOURCE="${ZERO_HOUR_ENEMY_HIT_SOURCE:-$SOURCE/eleven_labs_enemy_killed.wav}"
TARGET="$PROJECT/assets/audio"

mkdir -p "$SOURCE" "$TARGET"
rm -rf "$SOURCE/sfx_wav"
python3 "$PROJECT/tools/audio/generate_sfx.py"

BGM_DURATION="$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$BGM_SOURCE")"
BGM_TAIL_START="$(awk -v duration="$BGM_DURATION" 'BEGIN { printf "%.6f", duration - 1.0 }')"
ffmpeg -hide_banner -loglevel error -y -i "$BGM_SOURCE" \
  -filter_complex "[0:a]asplit=3[body_src][tail_src][head_src];[body_src]atrim=start=1:end=${BGM_TAIL_START},asetpts=PTS-STARTPTS[body];[tail_src]atrim=start=${BGM_TAIL_START}:end=${BGM_DURATION},asetpts=PTS-STARTPTS[tail];[head_src]atrim=start=0:end=1,asetpts=PTS-STARTPTS[head];[tail][head]acrossfade=d=1:c1=tri:c2=tri[seam];[body][seam]concat=n=2:v=0:a=1,loudnorm=I=-16:TP=-1.5:LRA=7,aformat=sample_rates=48000:channel_layouts=stereo[out]" \
  -map "[out]" -c:a libvorbis -q:a 0 "$TARGET/zero_hour_bgm.ogg"

ffmpeg -hide_banner -loglevel error -y -i "$SLASH_SOURCE" \
  -af "volume=-0.8dB" -c:a libvorbis -q:a 5 "$TARGET/slash.ogg"

ffmpeg -hide_banner -loglevel error -y -i "$PARRY_SOURCE" \
  -af "volume=-0.8dB" -c:a libvorbis -q:a 5 "$TARGET/parry.ogg"

ffmpeg -hide_banner -loglevel error -y -i "$ENEMY_HIT_SOURCE" \
  -af "volume=-0.8dB" -c:a libvorbis -q:a 5 "$TARGET/enemy_hit.ogg"

for name in victory; do
  ffmpeg -hide_banner -loglevel error -y -i "$SOURCE/sfx_wav/$name.wav" \
    -af "highpass=f=70" -c:a libvorbis -q:a 5 "$TARGET/$name.ogg"
done

ffmpeg -hide_banner -loglevel error -y -i "$SOURCE/sfx_wav/rain_loop.wav" \
  -af "volume=-9dB,highpass=f=500,lowpass=f=13000" -c:a libvorbis -q:a 2 \
  "$TARGET/rain_loop.ogg"

for name in thunder_1 thunder_2 thunder_3; do
  ffmpeg -hide_banner -loglevel error -y -i "$SOURCE/sfx_wav/$name.wav" \
    -af "volume=-4dB,highpass=f=28,lowpass=f=9000" -c:a libvorbis -q:a 3 \
    "$TARGET/$name.ogg"
done

find "$TARGET" -maxdepth 1 -type f -name '*.ogg' -printf '%f %k KB\n' | sort
