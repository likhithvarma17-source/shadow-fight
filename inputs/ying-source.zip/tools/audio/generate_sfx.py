from __future__ import annotations

import math
import os
import wave
from pathlib import Path

import numpy as np

SAMPLE_RATE = 48_000
PROJECT = Path(__file__).resolve().parents[2]
OUTPUT = Path(os.environ.get("ZERO_HOUR_AUDIO_SOURCE", PROJECT.parent / "zero-hour-audio-sources")) / "sfx_wav"


def write_wav(name: str, samples: np.ndarray, peak: float = 0.92) -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    samples = np.asarray(samples, dtype=np.float64)
    maximum = float(np.max(np.abs(samples)))
    if maximum > 0.0:
        samples = samples * (peak / maximum)
    pcm = np.clip(samples, -1.0, 1.0)
    pcm = (pcm * 32767.0).astype("<i2")
    with wave.open(str(OUTPUT / name), "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(SAMPLE_RATE)
        wav.writeframes(pcm.tobytes())


def time_axis(duration: float) -> np.ndarray:
    return np.arange(int(SAMPLE_RATE * duration), dtype=np.float64) / SAMPLE_RATE


def smooth_noise(duration: float, seed: int, smoothing: float) -> np.ndarray:
    rng = np.random.default_rng(seed)
    white = rng.normal(0.0, 1.0, int(SAMPLE_RATE * duration))
    result = np.zeros_like(white)
    alpha = math.exp(-1.0 / max(1.0, SAMPLE_RATE * smoothing))
    for index in range(1, len(white)):
        result[index] = alpha * result[index - 1] + (1.0 - alpha) * white[index]
    return result


def high_noise(duration: float, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    white = rng.normal(0.0, 1.0, int(SAMPLE_RATE * duration))
    low = smooth_noise(duration, seed + 1000, 0.0008)
    return white - low


def resonant_cluster(t: np.ndarray, frequencies: list[float], decay: float, phases: np.ndarray) -> np.ndarray:
    cluster = np.zeros_like(t)
    for index, frequency in enumerate(frequencies):
        wobble = 1.0 + 0.0018 * np.sin(2.0 * np.pi * (2.3 + index * 0.7) * t)
        cluster += np.sin(2.0 * np.pi * frequency * wobble * t + phases[index]) / (1.0 + index * 0.38)
    return cluster * np.exp(-t * decay)


def make_slash() -> np.ndarray:
    duration = 0.30
    t = time_axis(duration)
    rng = np.random.default_rng(31)
    noise = rng.normal(0.0, 1.0, len(t))
    sweep_phase = 2.0 * np.pi * (2600.0 * t - 1500.0 * t * t)
    sweep = np.sin(sweep_phase) * np.exp(-((t - 0.105) / 0.075) ** 2)
    whoosh = np.convolve(noise, np.ones(96) / 96.0, mode="same")
    envelope = np.exp(-((t - 0.12) / 0.085) ** 2)
    edge = np.sin(2.0 * np.pi * 5100.0 * t) * np.exp(-t * 28.0)
    return np.tanh((sweep * 0.9 + whoosh * envelope * 5.2 + edge * 0.18) * 1.4)


def make_parry() -> np.ndarray:
    duration = 0.38
    t = time_axis(duration)
    rng = np.random.default_rng(43)
    phases = rng.uniform(0.0, 2.0 * np.pi, 5)
    ring = resonant_cluster(t, [1280, 2160, 3290, 4610, 6180], 10.8, phases)
    spark = high_noise(duration, 47) * np.exp(-t * 52.0)
    attack = np.exp(-((t - 0.008) / 0.006) ** 2)
    return np.tanh((ring * 0.7 + spark * 0.42 + attack * 0.9) * 1.7)


def make_hit() -> np.ndarray:
    duration = 0.48
    t = time_axis(duration)
    rng = np.random.default_rng(59)
    phases = rng.uniform(0.0, 2.0 * np.pi, 6)
    body = resonant_cluster(t, [170, 315, 620, 1120, 2050, 3560], 8.2, phases)
    impact = high_noise(duration, 61) * np.exp(-t * 31.0)
    return np.tanh((body * 0.95 + impact * 0.34) * 1.8)


def make_player_down() -> np.ndarray:
    duration = 0.78
    t = time_axis(duration)
    rng = np.random.default_rng(71)
    phases = rng.uniform(0.0, 2.0 * np.pi, 5)
    metal = resonant_cluster(t, [110, 238, 487, 965, 1935], 5.8, phases)
    rewind = np.sin(2.0 * np.pi * (1400.0 * t - 810.0 * t * t)) * np.exp(-((t - 0.42) / 0.23) ** 2)
    noise = high_noise(duration, 73) * np.exp(-t * 8.5)
    return np.tanh((metal * 0.75 + rewind * 0.24 + noise * 0.18) * 1.5)


def make_victory() -> np.ndarray:
    duration = 0.92
    t = time_axis(duration)
    first = np.sin(2.0 * np.pi * 880.0 * t) * np.exp(-t * 5.3)
    second_t = np.maximum(0.0, t - 0.18)
    second = np.sin(2.0 * np.pi * 1320.0 * second_t) * np.exp(-second_t * 4.8) * (t >= 0.18)
    shimmer = np.sin(2.0 * np.pi * 2640.0 * t) * np.exp(-t * 7.4)
    return np.tanh((first * 0.55 + second * 0.62 + shimmer * 0.22) * 1.4)


def make_rain_loop() -> np.ndarray:
    duration = 12.0
    fade = 1.0
    total = duration + fade
    rng = np.random.default_rng(101)
    white = rng.normal(0.0, 1.0, int(SAMPLE_RATE * total))
    low = smooth_noise(total, 103, 0.003)
    rain = (white - low) * 0.22 + smooth_noise(total, 107, 0.00035) * 0.7
    for _ in range(420):
        start = int(rng.uniform(0.0, total) * SAMPLE_RATE)
        length = int(rng.uniform(0.012, 0.055) * SAMPLE_RATE)
        end = min(len(rain), start + length)
        local_t = np.arange(end - start) / SAMPLE_RATE
        frequency = rng.uniform(1900.0, 6200.0)
        drop = np.sin(2.0 * np.pi * frequency * local_t) * np.exp(-local_t * rng.uniform(75.0, 160.0))
        rain[start:end] += drop * rng.uniform(0.04, 0.16)
    loop_samples = int(duration * SAMPLE_RATE)
    fade_samples = int(fade * SAMPLE_RATE)
    result = rain[:loop_samples].copy()
    blend = np.linspace(0.0, 1.0, fade_samples)
    result[:fade_samples] = result[:fade_samples] * blend + rain[loop_samples : loop_samples + fade_samples] * (1.0 - blend)
    return np.tanh(result * 1.55)


def make_thunder(seed: int, duration: float, crack_time: float) -> np.ndarray:
    t = time_axis(duration)
    rng = np.random.default_rng(seed)
    rumble = smooth_noise(duration, seed, 0.012) * 8.0
    sub = smooth_noise(duration, seed + 1, 0.028) * 16.0
    envelope = (1.0 - np.exp(-t * 18.0)) * np.exp(-t * rng.uniform(0.55, 0.82))
    crack = high_noise(duration, seed + 2) * np.exp(-np.maximum(0.0, t - crack_time) * 24.0) * (t >= crack_time)
    boom = np.sin(2.0 * np.pi * rng.uniform(42.0, 61.0) * np.maximum(0.0, t - crack_time))
    boom *= np.exp(-np.maximum(0.0, t - crack_time) * 1.55) * (t >= crack_time)
    return np.tanh((rumble * 0.75 + sub * 0.48) * envelope + crack * 0.32 + boom * 0.62)


def main() -> None:
    write_wav("slash.wav", make_slash())
    write_wav("parry.wav", make_parry())
    write_wav("enemy_hit.wav", make_hit())
    write_wav("player_down.wav", make_player_down())
    write_wav("victory.wav", make_victory())
    write_wav("rain_loop.wav", make_rain_loop(), peak=0.72)
    write_wav("thunder_1.wav", make_thunder(201, 4.2, 0.025))
    write_wav("thunder_2.wav", make_thunder(223, 5.1, 0.09))
    write_wav("thunder_3.wav", make_thunder(247, 3.8, 0.0))
    print(f"Generated 9 source effects in {OUTPUT}")


if __name__ == "__main__":
    main()
